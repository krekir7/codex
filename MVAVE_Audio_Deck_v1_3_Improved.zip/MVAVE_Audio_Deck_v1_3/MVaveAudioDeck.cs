﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Drawing;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;

namespace MVaveAudioDeck
{
    internal static class MidiNative
    {
        public const uint CALLBACK_FUNCTION = 0x00030000;
        public const uint MIM_DATA = 0x3C3;
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct MIDIINCAPS
        {
            public ushort wMid;
            public ushort wPid;
            public uint vDriverVersion;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szPname;
            public uint dwSupport;
        }
        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        public delegate void MidiInProc(IntPtr h, uint msg, IntPtr instance, IntPtr param1, IntPtr param2);
        [DllImport("winmm.dll")] public static extern uint midiInGetNumDevs();
        [DllImport("winmm.dll", CharSet = CharSet.Unicode)] public static extern uint midiInGetDevCaps(UIntPtr id, out MIDIINCAPS caps, uint size);
        [DllImport("winmm.dll")] public static extern uint midiInOpen(out IntPtr h, uint id, MidiInProc callback, IntPtr instance, uint flags);
        [DllImport("winmm.dll")] public static extern uint midiInStart(IntPtr h);
        [DllImport("winmm.dll")] public static extern uint midiInStop(IntPtr h);
        [DllImport("winmm.dll")] public static extern uint midiInReset(IntPtr h);
        [DllImport("winmm.dll")] public static extern uint midiInClose(IntPtr h);
    }

    internal struct MidiEvent
    {
        public uint Raw;
        public string Device;
        public MidiEvent(uint raw, string device) { Raw = raw; Device = device; }
    }

    internal sealed class MidiPorts : IDisposable
    {
        private sealed class Endpoint
        {
            public IntPtr Handle = IntPtr.Zero;
            public MidiNative.MidiInProc Callback;
            public string Name;
            public volatile bool Accepting = true;
        }
        private const int MaxQueuedEvents = 4096;
        private readonly List<Endpoint> opened = new List<Endpoint>();
        private readonly ConcurrentQueue<MidiEvent> queue;
        private int droppedEvents;
        public MidiPorts(ConcurrentQueue<MidiEvent> q) { queue = q; }
        public bool IsOpen { get { return opened.Count > 0; } }
        public int OpenCount { get { return opened.Count; } }
        public int TakeDroppedEventCount() { return Interlocked.Exchange(ref droppedEvents, 0); }
        public static List<string> Enumerate()
        {
            List<string> names = new List<string>();
            uint count = MidiNative.midiInGetNumDevs();
            for (uint i = 0; i < count; i++)
            {
                MidiNative.MIDIINCAPS caps;
                uint result = MidiNative.midiInGetDevCaps(new UIntPtr(i), out caps, (uint)Marshal.SizeOf(typeof(MidiNative.MIDIINCAPS)));
                names.Add(result == 0 ? caps.szPname : "MIDI input #" + i.ToString());
            }
            return names;
        }
        public void Open(IEnumerable<int> selected, IList<string> deviceNames)
        {
            Close();
            List<string> errors = new List<string>();
            foreach (int id in selected)
            {
                if (id < 0 || id >= deviceNames.Count) continue;
                Endpoint endpoint = new Endpoint();
                endpoint.Name = deviceNames[id];
                Endpoint current = endpoint;
                endpoint.Callback = delegate(IntPtr h, uint msg, IntPtr i, IntPtr p1, IntPtr p2)
                {
                    if (msg != MidiNative.MIM_DATA || !current.Accepting) return;
                    uint raw = unchecked((uint)p1.ToInt64());
                    uint status = raw & 0xF0;
                    // Ignore clock, active sensing and other messages the deck cannot use.
                    if (status != 0x80 && status != 0x90 && status != 0xB0 && status != 0xE0) return;
                    // A modal file picker must not allow an unattended controller to exhaust memory.
                    if (queue.Count >= MaxQueuedEvents)
                    {
                        MidiEvent discarded;
                        if (queue.TryDequeue(out discarded)) Interlocked.Increment(ref droppedEvents);
                    }
                    queue.Enqueue(new MidiEvent(raw, current.Name));
                };
                uint rc = MidiNative.midiInOpen(out endpoint.Handle, (uint)id, endpoint.Callback, IntPtr.Zero, MidiNative.CALLBACK_FUNCTION);
                if (rc == 0 && endpoint.Handle != IntPtr.Zero)
                {
                    rc = MidiNative.midiInStart(endpoint.Handle);
                    if (rc == 0) { opened.Add(endpoint); continue; }
                    endpoint.Accepting = false;
                    MidiNative.midiInClose(endpoint.Handle);
                }
                errors.Add(endpoint.Name + " (код " + rc.ToString() + ")");
            }
            if (opened.Count == 0) throw new IOException("Не удалось открыть выбранные MIDI-входы. " + String.Join("; ", errors.ToArray()) + ". Закрой MIDI-OX и MidiSuite.");
            if (errors.Count > 0) throw new IOException("Открыто " + opened.Count.ToString() + " портов, но недоступны: " + String.Join("; ", errors.ToArray()));
        }
        public void Close()
        {
            foreach (Endpoint endpoint in opened) endpoint.Accepting = false;
            foreach (Endpoint endpoint in opened)
            {
                try { MidiNative.midiInStop(endpoint.Handle); } catch { }
                try { MidiNative.midiInReset(endpoint.Handle); } catch { }
                try { MidiNative.midiInClose(endpoint.Handle); } catch { }
                endpoint.Handle = IntPtr.Zero;
                endpoint.Callback = null;
            }
            opened.Clear();
            MidiEvent discarded;
            while (queue.TryDequeue(out discarded)) { }
            Interlocked.Exchange(ref droppedEvents, 0);
        }
        public void Dispose() { Close(); }
    }

    // Core Audio: volume control for Windows default playback device and active app sessions.
    internal static class WindowsAudio
    {
        [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
        internal class MMDeviceEnumeratorClass { }
        [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        internal interface IMMDeviceEnumerator
        {
            [PreserveSig] int EnumAudioEndpoints(int flow, int stateMask, out IntPtr devices);
            [PreserveSig] int GetDefaultAudioEndpoint(int flow, int role, out IMMDevice endpoint);
            [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out IMMDevice endpoint);
            [PreserveSig] int RegisterEndpointNotificationCallback(IntPtr p);
            [PreserveSig] int UnregisterEndpointNotificationCallback(IntPtr p);
        }
        [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        internal interface IMMDevice
        {
            [PreserveSig] int Activate(ref Guid iid, int clsctx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object obj);
        }
        [ComImport, Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        internal interface IAudioSessionManager2
        {
            int GetAudioSessionControlPlaceholder();
            int GetSimpleAudioVolumePlaceholder();
            [PreserveSig] int GetSessionEnumerator(out IAudioSessionEnumerator sessions);
        }
        [ComImport, Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        internal interface IAudioSessionEnumerator
        {
            [PreserveSig] int GetCount(out int count);
            [PreserveSig] int GetSession(int index, out IAudioSessionControl2 session);
        }
        [ComImport, Guid("bfb7ff88-7239-4fc9-8fa2-07c950be9c6d"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        internal interface IAudioSessionControl2
        {
            [PreserveSig] int GetState(out int state);
            [PreserveSig] int GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] out string name);
            [PreserveSig] int SetDisplayName(IntPtr name, IntPtr context);
            [PreserveSig] int GetIconPath(out IntPtr path);
            [PreserveSig] int SetIconPath(IntPtr path, IntPtr context);
            [PreserveSig] int GetGroupingParam(out Guid guid);
            [PreserveSig] int SetGroupingParam(ref Guid guid, ref Guid eventContext);
            [PreserveSig] int RegisterAudioSessionNotification(IntPtr p);
            [PreserveSig] int UnregisterAudioSessionNotification(IntPtr p);
            [PreserveSig] int GetSessionIdentifier(out IntPtr value);
            [PreserveSig] int GetSessionInstanceIdentifier(out IntPtr value);
            [PreserveSig] int GetProcessId(out uint pid);
        }
        [ComImport, Guid("87CE5498-68D6-44E5-9215-6DA47EF883D8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        internal interface ISimpleAudioVolume
        {
            [PreserveSig] int SetMasterVolume(float level, ref Guid eventContext);
            [PreserveSig] int GetMasterVolume(out float level);
            [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool muted, ref Guid eventContext);
            [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool muted);
        }
        [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        internal interface IAudioEndpointVolume
        {
            int RegisterControlChangeNotify(IntPtr p);
            int UnregisterControlChangeNotify(IntPtr p);
            int GetChannelCount(out uint count);
            int SetMasterVolumeLevel(float level, ref Guid guid);
            [PreserveSig] int SetMasterVolumeLevelScalar(float level, ref Guid guid);
            int GetMasterVolumeLevel(out float level);
            [PreserveSig] int GetMasterVolumeLevelScalar(out float level);
        }
        private static void Release(object o) { if (o != null && Marshal.IsComObject(o)) Marshal.ReleaseComObject(o); }
        private static string GetProcessName(uint pid)
        {
            try
            {
                using (Process process = Process.GetProcessById((int)pid))
                    return process.ProcessName.ToLowerInvariant() + ".exe";
            }
            catch { return ""; }
        }
        private static IMMDevice GetSpeaker(out IMMDeviceEnumerator enumerator)
        {
            enumerator = (IMMDeviceEnumerator)new MMDeviceEnumeratorClass();
            IMMDevice speaker;
            Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(0, 1, out speaker));
            return speaker;
        }
        private static IAudioSessionManager2 GetManager(IMMDevice speaker)
        {
            Guid iid = typeof(IAudioSessionManager2).GUID;
            object obj;
            Marshal.ThrowExceptionForHR(speaker.Activate(ref iid, 23, IntPtr.Zero, out obj));
            return (IAudioSessionManager2)obj;
        }
        public static List<string> ListApps()
        {
            List<string> list = new List<string>();
            IMMDeviceEnumerator en = null; IMMDevice sp = null;
            IAudioSessionManager2 mgr = null; IAudioSessionEnumerator sessions = null;
            try
            {
                sp = GetSpeaker(out en); mgr = GetManager(sp);
                Marshal.ThrowExceptionForHR(mgr.GetSessionEnumerator(out sessions));
                int n; Marshal.ThrowExceptionForHR(sessions.GetCount(out n));
                for (int i = 0; i < n; i++)
                {
                    IAudioSessionControl2 control = null;
                    try
                    {
                        if (sessions.GetSession(i, out control) != 0 || control == null) continue;
                        uint pid; if (control.GetProcessId(out pid) != 0 || pid == 0) continue;
                        string name = GetProcessName(pid);
                        if (name.Length > 0 && !list.Contains(name)) list.Add(name);
                    }
                    finally { Release(control); }
                }
            }
            finally { Release(sessions); Release(mgr); Release(sp); Release(en); }
            list.Sort(StringComparer.CurrentCultureIgnoreCase);
            list.Insert(0, "[СИСТЕМНАЯ ГРОМКОСТЬ]");
            return list;
        }
        // Process-name matching is resilient when Chrome/Discord restarts or uses more than one audio session.
        public static int SetVolume(string name, int pct)
        {
            pct = Math.Max(0, Math.Min(100, pct));
            if (String.IsNullOrWhiteSpace(name)) return 0;
            if (name == "[СИСТЕМНАЯ ГРОМКОСТЬ]")
            {
                IMMDeviceEnumerator en = null; IMMDevice sp = null; object volObj = null;
                try
                {
                    sp = GetSpeaker(out en);
                    Guid iid = typeof(IAudioEndpointVolume).GUID;
                    Marshal.ThrowExceptionForHR(sp.Activate(ref iid, 23, IntPtr.Zero, out volObj));
                    Guid guid = Guid.Empty;
                    Marshal.ThrowExceptionForHR(((IAudioEndpointVolume)volObj).SetMasterVolumeLevelScalar(pct / 100f, ref guid));
                    return 1;
                }
                finally { Release(volObj); Release(sp); Release(en); }
            }
            name = name.Trim().ToLowerInvariant();
            if (!name.EndsWith(".exe")) name += ".exe";
            IMMDeviceEnumerator de = null; IMMDevice speaker = null;
            IAudioSessionManager2 mgr = null; IAudioSessionEnumerator sessions = null;
            int changed = 0;
            try
            {
                speaker = GetSpeaker(out de); mgr = GetManager(speaker);
                Marshal.ThrowExceptionForHR(mgr.GetSessionEnumerator(out sessions));
                int n; Marshal.ThrowExceptionForHR(sessions.GetCount(out n));
                for (int i = 0; i < n; i++)
                {
                    IAudioSessionControl2 control = null;
                    try
                    {
                        if (sessions.GetSession(i, out control) != 0 || control == null) continue;
                        uint pid; if (control.GetProcessId(out pid) != 0 || pid == 0) continue;
                        if (GetProcessName(pid) != name) continue;
                        ISimpleAudioVolume volume = control as ISimpleAudioVolume;
                        if (volume == null) continue;
                        Guid context = Guid.Empty;
                        if (volume.SetMasterVolume(pct / 100f, ref context) == 0) changed++;
                    }
                    finally { Release(control); }
                }
            }
            finally { Release(sessions); Release(mgr); Release(speaker); Release(de); }
            return changed;
        }
        public static int? GetVolume(string name)
        {
            if (String.IsNullOrWhiteSpace(name)) return null;
            if (name == "[СИСТЕМНАЯ ГРОМКОСТЬ]")
            {
                IMMDeviceEnumerator en = null; IMMDevice sp = null; object obj = null;
                try
                {
                    sp = GetSpeaker(out en); Guid iid = typeof(IAudioEndpointVolume).GUID;
                    Marshal.ThrowExceptionForHR(sp.Activate(ref iid, 23, IntPtr.Zero, out obj));
                    float value; Marshal.ThrowExceptionForHR(((IAudioEndpointVolume)obj).GetMasterVolumeLevelScalar(out value));
                    return (int)Math.Round(value * 100);
                }
                finally { Release(obj); Release(sp); Release(en); }
            }
            name = name.Trim().ToLowerInvariant();
            if (!name.EndsWith(".exe")) name += ".exe";
            IMMDeviceEnumerator de = null; IMMDevice speaker = null;
            IAudioSessionManager2 mgr = null; IAudioSessionEnumerator sessions = null;
            try
            {
                speaker = GetSpeaker(out de); mgr = GetManager(speaker);
                Marshal.ThrowExceptionForHR(mgr.GetSessionEnumerator(out sessions));
                int n; Marshal.ThrowExceptionForHR(sessions.GetCount(out n));
                for (int i = 0; i < n; i++)
                {
                    IAudioSessionControl2 control = null;
                    try
                    {
                        if (sessions.GetSession(i, out control) != 0 || control == null) continue;
                        uint pid; if (control.GetProcessId(out pid) != 0 || pid == 0) continue;
                        if (GetProcessName(pid) != name) continue;
                        ISimpleAudioVolume volume = control as ISimpleAudioVolume;
                        if (volume == null) continue;
                        float value;
                        if (volume.GetMasterVolume(out value) == 0) return (int)Math.Round(100 * value);
                    }
                    finally { Release(control); }
                }
            }
            finally { Release(sessions); Release(mgr); Release(speaker); Release(de); }
            return null;
        }
    }

    // Lightweight VB-CABLE presence check; uses only Windows built-in waveOut device enumeration.
    internal static class AudioRouteDevices
    {
        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
        private struct WAVEOUTCAPS
        {
            public ushort wMid, wPid;
            public uint vDriverVersion;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szPname;
            public uint dwFormats;
            public ushort wChannels, wReserved;
            public uint dwSupport;
        }
        [DllImport("winmm.dll", CharSet=CharSet.Unicode, EntryPoint="waveOutGetDevCapsW")]
        private static extern uint GetCaps(UIntPtr deviceId, out WAVEOUTCAPS caps, uint cb);
        [DllImport("winmm.dll")]
        private static extern uint waveOutGetNumDevs();
        public static string FindVirtualCable()
        {
            uint total=waveOutGetNumDevs();
            for(uint i=0;i<total;i++)
            {
                WAVEOUTCAPS caps;
                if(GetCaps(new UIntPtr(i),out caps,(uint)Marshal.SizeOf(typeof(WAVEOUTCAPS)))!=0)continue;
                string name=caps.szPname ?? "";
                if(name.IndexOf("CABLE Input",StringComparison.OrdinalIgnoreCase)>=0 ||
                   name.IndexOf("VB-Audio",StringComparison.OrdinalIgnoreCase)>=0)
                    return name;
            }
            return "";
        }
    }

    internal sealed class SoundBoard : IDisposable
    {
        [DllImport("winmm.dll", CharSet = CharSet.Unicode, EntryPoint = "mciSendStringW")]
        private static extern uint Send(string cmd, StringBuilder ret, uint retLen, IntPtr hwnd);
        [DllImport("winmm.dll", CharSet = CharSet.Unicode, EntryPoint = "mciGetErrorStringW")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetError(uint code, StringBuilder description, uint length);
        private readonly Dictionary<int,string> active = new Dictionary<int,string>();
        private int nextId = 0;
        public int ActiveCount { get { return active.Count; } }
        public bool IsPlaying(int index)
        {
            string alias;
            if (!active.TryGetValue(index, out alias)) return false;
            StringBuilder val = new StringBuilder(64);
            uint err = Send("status " + alias + " mode", val, 64, IntPtr.Zero);
            if (err == 0 && val.ToString().Trim().Equals("playing", StringComparison.OrdinalIgnoreCase)) return true;
            // MCI keeps completed files open until explicitly closed.
            Stop(index);
            return false;
        }
        public void ReapFinished()
        {
            foreach (int index in new List<int>(active.Keys)) IsPlaying(index);
        }
        public void Play(int index, string path, bool toggle)
        {
            if (String.IsNullOrWhiteSpace(path) || !File.Exists(path)) throw new IOException("Файл звука не найден: " + path);
            if (path.Contains("\"")) throw new IOException("Неподдерживаемая кавычка в пути к звуку.");
            bool wasPlaying = IsPlaying(index);
            Stop(index);
            if (toggle && wasPlaying) return;
            ReapFinished();
            string alias = "deck" + (++nextId).ToString(CultureInfo.InvariantCulture);
            string kind = Path.GetExtension(path).ToLowerInvariant() == ".wav" ? "waveaudio" : "mpegvideo";
            uint code = Send("open \"" + path + "\" type " + kind + " alias " + alias, null, 0, IntPtr.Zero);
            if (code != 0) throw new IOException("Windows не смог воспроизвести этот формат: " + Describe(code));
            code = Send("play " + alias + " from 0", null, 0, IntPtr.Zero);
            if (code != 0) { Send("close " + alias, null, 0, IntPtr.Zero); throw new IOException(Describe(code)); }
            active[index] = alias;
        }
        public void Stop(int index)
        {
            string alias;
            if (!active.TryGetValue(index, out alias)) return;
            Send("stop " + alias, null, 0, IntPtr.Zero);
            Send("close " + alias, null, 0, IntPtr.Zero);
            active.Remove(index);
        }
        public void StopAll()
        {
            foreach (int index in new List<int>(active.Keys)) Stop(index);
        }
        private static string Describe(uint code)
        {
            StringBuilder buf = new StringBuilder(256);
            return GetError(code, buf, 256) ? buf.ToString() : "MCI error " + code;
        }
        public void Dispose() { StopAll(); }
    }
    internal class Binding
    {
        public string Kind;
        public int Index;
        public string Source = "";
        public string Port = "";
        public int Channel = 1;
        public int Number = -1;
        public int LastValue = -1;
        public int CurrentPct = -1;
        public int PendingPct = -1;
        public DateTime LastApplied = DateTime.MinValue;
        public string Target = "";
        public string FileName = "";
        public string PlayMode = "Играть";
        public bool ButtonDown = false;
        public string Info { get { return Number < 0 ? "— не обучен —" : Source + " " + Number + " / ch " + Channel; } }
        public Binding(string kind, int index) { Kind = kind; Index = index; }
    }

    internal sealed class DeckForm : Form
    {
        private readonly Color dark = DeckPalette.Background;
        private readonly Color panel = DeckPalette.Surface;
        private readonly Color panelLight = DeckPalette.Raised;
        private readonly Color fg = DeckPalette.Text;
        private readonly Color dim = DeckPalette.Muted;
        private readonly Color cyan = DeckPalette.Accent;
        private readonly List<Binding> bindings = new List<Binding>();
        private readonly ConcurrentQueue<MidiEvent> incoming = new ConcurrentQueue<MidiEvent>();
        private readonly Dictionary<string,LearnData> learn = new Dictionary<string,LearnData>();
        private MidiPorts midi;
        private SoundBoard sounds = new SoundBoard();
        private CheckedListBox portList;
        private Button connectButton, refreshButton, saveButton;
        private Label connectionLabel, liveLabel, actionLabel, cableStatus;
        private TabControl tabs;
        private Panel[] strips = new Panel[8];
        private ComboBox[] faderApp = new ComboBox[8], knobApp = new ComboBox[8], knobMode = new ComboBox[8];
        private DeckFader[] faderLevel = new DeckFader[8];
        private Label[] faderValue = new Label[8], faderMidi = new Label[8], knobMidi = new Label[8];
        private readonly Dictionary<string,DataGridView> buttonGrids = new Dictionary<string,DataGridView>();
        private Binding learning;
        private DateTime learnStart;
        private System.Windows.Forms.Timer timer;
        private NotifyIcon trayIcon;
        private bool exitRequested = false;
        private bool trayHintShown = false;
        private List<string> apps = new List<string>();
        private DateTime lastPlaybackRefresh = DateTime.MinValue;
        private DateTime lastSaveEdit = DateTime.MinValue;
        private bool settingsDirty, refreshingCombos;
        private readonly bool previewMode;
        private readonly ToolTip hints = new ToolTip();
        private readonly Dictionary<string, SoundPad[]> soundPads = new Dictionary<string, SoundPad[]>();
        private readonly int[] knobPendingSteps = new int[8];
        private Label playingLabel;
        private DateTime lastAudioError = DateTime.MinValue;
        private int[] savedEncoderModes = new int[8];
        private bool initializing = true;
        private string configPath;
        private sealed class LearnData
        {
            public string Source, Port; public int Channel, Number, Count = 0, Min = int.MaxValue, Max = int.MinValue;
            public void Add(int n) { Count++; Min = Math.Min(Min, n); Max = Math.Max(Max, n); }
        }
        private Binding B(string kind, int index) { return bindings.Find(delegate(Binding b) { return b.Kind == kind && b.Index == index; }); }
        private static string Key(Binding b) { return b.Kind + b.Index.ToString(CultureInfo.InvariantCulture); }
        private static int Clamp(int n) { return Math.Max(0, Math.Min(100, n)); }
        private static string Display(string s) { return String.IsNullOrEmpty(s) ? "(не назначено)" : s; }
        private Label L(string t, int x, int y, int w, int h, int size, bool strong, Color color)
        {
            Label l = new Label(); l.Text = t; l.SetBounds(x,y,w,h); l.ForeColor = color;
            l.Font = new Font("Segoe UI", size, strong ? FontStyle.Bold : FontStyle.Regular);
            l.TextAlign = ContentAlignment.MiddleLeft; l.AutoEllipsis=true; return l;
        }
        private Button Btn(string s, int x, int y, int w, int h, Action click, bool primary)
        {
            DeckButton b = new DeckButton(); b.Text=s; b.SetBounds(x,y,w,h);
            b.Primary=primary; b.Click+=delegate{click();}; return b;
        }
        private ComboBox Combo(int x, int y, int w, int h)
        {
            ComboBox c=new ComboBox(); c.SetBounds(x,y,w,h); c.DropDownStyle=ComboBoxStyle.DropDown;
            c.BackColor=panelLight; c.ForeColor=fg; c.FlatStyle=FlatStyle.Flat; c.Font=new Font("Segoe UI",9);
            c.DropDownWidth=240; c.DropDown+=delegate {RefreshApps(false);}; return c;
        }
        public DeckForm() : this(false) { }
        public DeckForm(bool preview)
        {
            previewMode=preview;
            Text="M-VAVE Audio Deck 1.3"; BackColor=dark; ForeColor=fg; Font=new Font("Segoe UI",9);
            AutoScaleMode=AutoScaleMode.Dpi; DoubleBuffered=true;
            ClientSize=new Size(Math.Min(1280,Screen.PrimaryScreen.WorkingArea.Width-48),Math.Min(830,Screen.PrimaryScreen.WorkingArea.Height-72));MinimumSize=new Size(1040,680);
            StartPosition=FormStartPosition.CenterScreen; KeyPreview=true;
            configPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"MVAVE Audio Deck\\settings.xml");
            for(int i=1;i<=8;i++){bindings.Add(new Binding("Fader",i));bindings.Add(new Binding("Knob",i));}
            for(int i=1;i<=11;i++)bindings.Add(new Binding("Main",i));
            for(int i=1;i<=32;i++)bindings.Add(new Binding("Track",i));
            if(!previewMode) LoadSettings();
            midi=new MidiPorts(incoming);
            if(previewMode)
            {
                string[] names={"[СИСТЕМНАЯ ГРОМКОСТЬ]","Discord.exe","Spotify.exe","browser.exe","steam.exe","game.exe","",""};
                for(int i=0;i<8;i++) B("Fader",i+1).Target=names[i];
                B("Main",1).FileName=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Demo_Sounds/Chime.wav");
                B("Main",2).FileName=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Demo_Sounds/Click.wav");
            }
            BuildUI();
            if(previewMode){apps.Add("[СИСТЕМНАЯ ГРОМКОСТЬ]");SyncMappings();SetStatus("Предпросмотр интерфейса · устройства не подключаются");}
            else {RefreshPorts();RefreshApps(true);SyncMappings();}
            initializing=false;
            if(!String.IsNullOrEmpty(settingsWarning))SetStatus(settingsWarning);
            timer=new System.Windows.Forms.Timer();timer.Interval=25;timer.Tick+=Tick;
            if(!previewMode){timer.Start();InitializeTray();}
            FormClosing+=HandleFormClosing;
            KeyDown+=delegate(object sender,KeyEventArgs e){
                if(e.KeyCode==Keys.Escape){CancelLearn();e.Handled=true;}
                if(e.KeyCode==Keys.F12){StopAllSounds();e.Handled=true;}
                if(e.Control&&e.KeyCode==Keys.S){SaveSettings();e.Handled=true;e.SuppressKeyPress=true;}
            };
        }
        private void InitializeTray()
        {
            string iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "audio_deck.ico");
            try
            {
                if (File.Exists(iconPath)) Icon = new System.Drawing.Icon(iconPath);
                else Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            }
            catch { Icon = SystemIcons.Application; }

            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.Add("Открыть Audio Deck", null, delegate { RestoreFromTray(); });
            menu.Items.Add("Сохранить настройки", null, delegate { SaveSettings(); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Выход", null, delegate { ExitFromTray(); });

            trayIcon = new NotifyIcon();
            trayIcon.Icon = Icon ?? SystemIcons.Application;
            trayIcon.Text = "M-VAVE Audio Deck";
            trayIcon.ContextMenuStrip = menu;
            trayIcon.DoubleClick += delegate { RestoreFromTray(); };
            trayIcon.Visible = true;
        }
        private void HideToTray()
        {
            SaveSettings();
            ShowInTaskbar = false;
            Hide();
            if (trayIcon != null && !trayHintShown)
            {
                trayHintShown = true;
                trayIcon.BalloonTipTitle = "M-VAVE Audio Deck работает";
                trayIcon.BalloonTipText = "Фейдеры, энкодеры и саундборд активны. Дважды нажми на значок в трее, чтобы вернуть окно.";
                trayIcon.BalloonTipIcon = ToolTipIcon.Info;
                trayIcon.ShowBalloonTip(2200);
            }
        }
        private void RestoreFromTray()
        {
            if (IsDisposed) return;
            ShowInTaskbar = true;
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Show();
            for(int i=0;i<8;i++)
            {
                int pct=B("Fader",i+1).CurrentPct;
                if(pct>=0){faderLevel[i].Value=pct;faderValue[i].Text=pct+"%";}
            }
            RefreshPlayback();
            BringToFront();
            Activate();
        }
        private void ExitFromTray()
        {
            exitRequested = true;
            Close();
        }
        private void HandleFormClosing(object sender, FormClosingEventArgs e)
        {
            if (!previewMode && !exitRequested && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                HideToTray();
                return;
            }
            if (timer != null) {timer.Stop();timer.Dispose();}
            if(!previewMode) SaveSettings();
            hints.Dispose();
            if (midi != null) midi.Dispose();
            if (sounds != null) sounds.Dispose();
            if (trayIcon != null)
            {
                trayIcon.Visible = false;
                ContextMenuStrip menu = trayIcon.ContextMenuStrip;
                trayIcon.Dispose();
                if (menu != null) menu.Dispose();
                trayIcon = null;
            }
        }
        private void BuildUI()
        {
            SuspendLayout();
            TableLayoutPanel root=new TableLayoutPanel();root.Dock=DockStyle.Fill;root.Padding=new Padding(16,12,16,10);
            root.RowCount=4;root.ColumnCount=1;root.Margin=Padding.Empty;
            root.RowStyles.Add(new RowStyle(SizeType.Absolute,66));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute,85));
            root.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute,35));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Controls.Add(root);
            Panel header=new Panel();header.Dock=DockStyle.Fill;root.Controls.Add(header,0,0);
            header.Controls.Add(L("M-VAVE",0,0,120,32,20,true,cyan));
            header.Controls.Add(L("AUDIO DECK",130,0,330,32,20,true,fg));
            liveLabel=L("МИКШЕР ПРИЛОЖЕНИЙ  /  MIDI-САУНДБОРД",2,35,760,21,9,false,dim);header.Controls.Add(liveLabel);
            Button stop=Btn("СТОП ВСЁ  ·  F12",0,5,174,38,StopAllSounds,false);((DeckButton)stop).Danger=true;
            stop.Anchor=AnchorStyles.Top|AnchorStyles.Right;header.Controls.Add(stop);
            saveButton=Btn("Сохранить",0,5,130,38,delegate{if(SaveSettings())SetStatus("Настройки сохранены");},false);
            saveButton.Anchor=AnchorStyles.Top|AnchorStyles.Right;header.Controls.Add(saveButton);
            header.Resize+=delegate{stop.Left=header.ClientSize.Width-174;saveButton.Left=stop.Left-142;};
            DeckCard devices=new DeckCard();devices.Dock=DockStyle.Fill;devices.Margin=new Padding(0,0,0,10);root.Controls.Add(devices,0,1);
            TableLayoutPanel connection=new TableLayoutPanel();connection.Dock=DockStyle.Fill;connection.Padding=new Padding(14,10,14,9);
            connection.ColumnCount=4;connection.RowCount=1;
            connection.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,174));
            connection.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            connection.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,116));
            connection.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,158));devices.Controls.Add(connection);
            Panel deviceTitle=new Panel();deviceTitle.Dock=DockStyle.Fill;connection.Controls.Add(deviceTitle,0,0);
            deviceTitle.Controls.Add(L("MIDI-КОНТРОЛЛЕР",0,0,174,24,9,true,fg));
            connectionLabel=L("Не подключён",0,28,174,23,9,false,dim);deviceTitle.Controls.Add(connectionLabel);
            portList=new CheckedListBox();portList.Dock=DockStyle.Fill;portList.CheckOnClick=true;
            portList.BackColor=panel;portList.ForeColor=fg;portList.BorderStyle=BorderStyle.None;portList.IntegralHeight=false;
            portList.AccessibleName="MIDI-входы";connection.Controls.Add(portList,1,0);
            refreshButton=Btn("Обновить",0,0,104,36,RefreshPorts,false);refreshButton.Dock=DockStyle.Top;refreshButton.Margin=new Padding(6,8,6,0);connection.Controls.Add(refreshButton,2,0);
            connectButton=Btn("Подключить MIDI",0,0,150,36,ToggleMidi,true);connectButton.Dock=DockStyle.Top;connectButton.Margin=new Padding(6,8,0,0);connection.Controls.Add(connectButton,3,0);
            tabs=new TabControl();tabs.Dock=DockStyle.Fill;tabs.Font=new Font("Segoe UI",10,FontStyle.Bold);
            tabs.DrawMode=TabDrawMode.OwnerDrawFixed;tabs.ItemSize=new Size(173,40);tabs.SizeMode=TabSizeMode.Fixed;
            tabs.DrawItem+=delegate(object sender,DrawItemEventArgs e){
                Rectangle r=e.Bounds;bool selected=e.Index==tabs.SelectedIndex;
                using(SolidBrush br=new SolidBrush(selected?panel:dark))e.Graphics.FillRectangle(br,r);
                if(selected)using(Pen pen=new Pen(cyan,3))e.Graphics.DrawLine(pen,r.Left+15,r.Bottom-3,r.Right-15,r.Bottom-3);
                TextRenderer.DrawText(e.Graphics,tabs.TabPages[e.Index].Text,tabs.Font,r,selected?fg:dim,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);
            };root.Controls.Add(tabs,0,2);
            CreateMixerTab();CreateButtonTab("Саундборд · 11","Main",11);
            CreateButtonTab("Track · 32","Track",32);CreateRouteTab();
            TabPage info=new TabPage("Как пользоваться");info.BackColor=dark;info.Padding=new Padding(24);tabs.TabPages.Add(info);
            RichTextBox help=new RichTextBox();help.Dock=DockStyle.Fill;help.ReadOnly=true;help.BorderStyle=BorderStyle.None;
            help.BackColor=dark;help.ForeColor=fg;help.Font=new Font("Segoe UI",12);help.Text=
                "БЫСТРЫЙ СТАРТ\n\n"+
                "1. Подключите M-VAVE по USB и выберите MIDI-входы SMC-Mixer.\n"+
                "2. Нажмите «Подключить MIDI». Другие MIDI-программы не должны занимать порт.\n"+
                "3. Выберите приложение в канале. Если его нет — включите в нём звук и обновите список.\n"+
                "4. Нажмите «Обучить F» и проведите фейдер. Для энкодера — «Обучить K».\n"+
                "5. На саундборде выберите площадку и загрузите WAV, MP3 или WMA.\n"+
                "6. Один щелчок выбирает звук, двойной — воспроизводит. Правая кнопка открывает действия.\n\n"+
                "ГОРЯЧИЕ КЛАВИШИ\n\nF12 — остановить все звуки (пока окно активно).\nEsc — отменить MIDI-обучение. Ctrl+S — сохранить настройки.\n"+
                "Фейдер: стрелки — шаг 1%, колесо — 2%, Home / End — 0 / 100%.\n\n"+
                "НАСТРОЙКИ И ТРЕЙ\n\nИзменения сохраняются автоматически. Крестик скрывает окно в трей.\n"+
                "Для завершения: правая кнопка по значку в трее → Выход.\n"+
                "Настройки: %APPDATA%\\MVAVE Audio Deck\\settings.xml; предыдущая версия — .bak.\n\n"+
                "АУДИО И MIDI\n\nФейдеры: CC / Pitch Bend. Энкодеры: relative ±64 или Absolute CC.\n"+
                "Микшер управляет приложениями на устройстве вывода Windows по умолчанию.\n"+
                "Для Discord используйте вкладку «Discord / игры» и виртуальный аудиокабель.\n"+
                "Драйверы и системные устройства приложение самостоятельно не меняет.\n";
            info.Controls.Add(help);
            TableLayoutPanel footer=new TableLayoutPanel();footer.Dock=DockStyle.Fill;footer.ColumnCount=2;footer.RowCount=1;
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,170));
            actionLabel=L("Готово к работе",0,0,900,30,9,false,dim);actionLabel.Dock=DockStyle.Fill;footer.Controls.Add(actionLabel,0,0);
            playingLabel=L("Звуков: 0",0,0,160,30,9,false,cyan);playingLabel.Dock=DockStyle.Fill;playingLabel.TextAlign=ContentAlignment.MiddleRight;
            footer.Controls.Add(playingLabel,1,0);root.Controls.Add(footer,0,3);ResumeLayout(true);
        }
        private void LaunchRouteTool(string exe, string args)
        {
            try
            {
                using(Process p=new Process())
                {
                p.StartInfo.FileName=exe;
                p.StartInfo.Arguments=args;
                p.StartInfo.UseShellExecute=true;
                p.Start();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(this,"Не удалось открыть настройки Windows: "+ex.Message+"\n\nОткрой: Параметры → Система → Звук → Микшер громкости.","Настройка звука");
            }
        }
        private void CheckVirtualCable()
        {
            string name=previewMode?"":AudioRouteDevices.FindVirtualCable();
            if(cableStatus!=null)
            {
                cableStatus.Text=name.Length>0 ? "VB-CABLE: найден выход «"+name+"»" :
                    "VB-CABLE не обнаружен среди устройств воспроизведения Windows";
                cableStatus.ForeColor=name.Length>0?cyan:Color.FromArgb(255,181,121);
            }
        }
        private void CreateRouteTab()
        {
            TabPage page=new TabPage("Discord / игры");page.BackColor=dark;tabs.TabPages.Add(page);
            Panel scroll=new Panel();scroll.Dock=DockStyle.Fill;scroll.AutoScroll=true;page.Controls.Add(scroll);
            Panel content=new Panel();content.SetBounds(10,8,1170,790);content.BackColor=dark;scroll.Controls.Add(content);
            content.Controls.Add(L("ПЕРЕДАЧА ЗВУКОВ В DISCORD И ИГРЫ",12,8,1090,38,19,true,fg));
            content.Controls.Add(L("Саундборд → виртуальный кабель → микрофон Discord. Фейдеры и MIDI-бинды остаются без изменений.",14,50,1105,26,10,false,dim));
            cableStatus=L("Проверка виртуального кабеля...",14,90,1050,25,11,true,cyan);
            content.Controls.Add(cableStatus);
            content.Controls.Add(Btn("Проверить VB-CABLE",14,126,191,34,delegate {CheckVirtualCable();},false));
            content.Controls.Add(Btn("Скачать VB-CABLE",215,126,186,34,delegate {LaunchRouteTool("https://vb-audio.com/Cable/","");},true));
            content.Controls.Add(L("ШАГ 1     УСТАНОВИ VB-CABLE",14,183,1090,30,13,true,cyan));
            content.Controls.Add(L("Скачай бесплатный VB-CABLE, запусти VBCABLE_Setup_x64.exe от администратора и перезагрузи Windows.",14,218,1100,24,10,false,fg));
            content.Controls.Add(L("Появятся два устройства: CABLE Input (воспроизведение) и CABLE Output (запись).",14,244,1100,23,10,false,dim));
            content.Controls.Add(L("ШАГ 2     НАПРАВЬ ЗВУК ИМЕННО AUDIO DECK В КАБЕЛЬ",14,288,1100,30,13,true,cyan));
            content.Controls.Add(L("Запусти тестовый звук в саундборде, затем открой микшер Windows. Для MVAVE_Audio_Deck.exe",14,324,1100,22,10,false,fg));
            content.Controls.Add(L("выбери устройство вывода CABLE Input (VB-Audio Virtual Cable), остальные приложения оставь на наушниках.",14,350,1100,22,10,false,fg));
            content.Controls.Add(Btn("Открыть микшер Windows",14,384,240,34,delegate {LaunchRouteTool("ms-settings:apps-volume","");},true));
            content.Controls.Add(L("ШАГ 3     ВЫБЕРИ ВИРТУАЛЬНЫЙ МИКРОФОН В DISCORD",14,452,1100,30,13,true,cyan));
            content.Controls.Add(L("Discord → Настройки пользователя → Голос и видео → Устройство ввода: CABLE Output (VB-Audio).",14,488,1110,22,10,false,fg));
            content.Controls.Add(L("Для игры выбери CABLE Output в настройках голосового чата. Проверь в Discord тестом микрофона.",14,514,1110,22,10,false,fg));
            content.Controls.Add(Btn("Звуковые устройства Windows",14,550,255,34,delegate {LaunchRouteTool("mmsys.cpl","");},false));
            content.Controls.Add(L("ВАЖНО: ТВОЙ ГОЛОС + ЗВУКИ",14,614,1100,27,13,true,Color.FromArgb(255,197,120)));
            content.Controls.Add(L("Если выбрать CABLE Output как микрофон, друзья услышат звуки, но НЕ твой обычный микрофон.",14,649,1100,24,10,false,fg));
            content.Controls.Add(L("Чтобы передавать одновременно голос и звуки, смешай микрофон с VB-CABLE через Voicemeeter",14,676,1110,23,10,false,fg));
            content.Controls.Add(L("или включи «Прослушивать с данного устройства» у микрофона с выводом в CABLE Input (может быть задержка).",14,702,1110,23,10,false,dim));
            content.Controls.Add(L("Используй наушники: это снижает риск эха. Отключи шумоподавление Discord, если звуки обрезаются.",14,729,1110,23,10,false,dim));
            content.Controls.Add(Btn("Voicemeeter (для голоса + звуков)",14,754,325,30,delegate {LaunchRouteTool("https://vb-audio.com/Voicemeeter/","");},false));
            page.Resize += delegate {content.Width=Math.Max(1140,scroll.ClientSize.Width-24);};
            CheckVirtualCable();
        }

        private void CreateMixerTab()
        {
            TabPage page=new TabPage("Микшер · 8 каналов");page.BackColor=dark;tabs.TabPages.Add(page);
            TableLayoutPanel container=new TableLayoutPanel();container.Dock=DockStyle.Fill;container.RowCount=2;container.ColumnCount=1;
            container.RowStyles.Add(new RowStyle(SizeType.Absolute,58));container.RowStyles.Add(new RowStyle(SizeType.Percent,100));page.Controls.Add(container);
            Panel hint=new Panel();hint.Dock=DockStyle.Fill;container.Controls.Add(hint,0,0);
            hint.Controls.Add(L("ВАШ ЗВУК. ПОД ВАШИМ КОНТРОЛЕМ.",8,4,590,25,11,true,fg));
            hint.Controls.Add(L("8 фейдеров + 8 энкодеров  ·  выберите приложения и назначьте MIDI",8,30,760,20,9,false,dim));
            Button appRefresh=Btn("Обновить приложения",0,12,190,34,delegate{RefreshApps(true);},false);
            hint.Controls.Add(appRefresh);hint.Resize+=delegate{appRefresh.Left=hint.Width-198;};
            Panel scroll=new Panel();scroll.AutoScroll=true;scroll.Dock=DockStyle.Fill;container.Controls.Add(scroll,0,1);
            TableLayoutPanel layout=new TableLayoutPanel();layout.Location=new Point(0,6);layout.Size=new Size(1220,488);layout.ColumnCount=8;layout.RowCount=1;
            layout.Margin=Padding.Empty;
            for(int i=0;i<8;i++)layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,12.5f));
            scroll.Controls.Add(layout);scroll.Resize+=delegate{layout.Width=Math.Max(1200,scroll.ClientSize.Width-6);};
            for(int i=0;i<8;i++)
            {
                int index=i+1;
                DeckCard card=new DeckCard();card.Dock=DockStyle.Fill;card.Margin=new Padding(4,0,4,0);strips[i]=card;layout.Controls.Add(card,i,0);
                Label num=L("КАНАЛ "+index.ToString("00"),12,10,125,26,11,true,cyan);card.Controls.Add(num);
                card.Controls.Add(L("ФЕЙДЕР",12,45,125,18,8,true,dim));
                faderApp[i]=Combo(10,68,130,26);card.Controls.Add(faderApp[i]);faderApp[i].AccessibleName="Приложение фейдера "+index;
                faderApp[i].TextChanged+=delegate{if(!refreshingCombos)ChangeTarget(B("Fader",index),faderApp[index-1].Text);};
                faderValue[i]=L("—",10,102,130,32,20,true,fg);faderValue[i].TextAlign=ContentAlignment.MiddleCenter;card.Controls.Add(faderValue[i]);
                faderLevel[i]=new DeckFader();faderLevel[i].SetBounds(37,132,76,130);faderLevel[i].AccessibleName="Громкость канала "+index;
                card.Controls.Add(faderLevel[i]);faderLevel[i].Scroll+=delegate{SetStripVolume(B("Fader",index),faderLevel[index-1].Value);};
                faderMidi[i]=L(B("Fader",index).Info,10,269,130,19,8,false,dim);card.Controls.Add(faderMidi[i]);
                Button flLearn=Btn("Обучить F",10,295,94,30,delegate{ArmLearn(B("Fader",index));},false);card.Controls.Add(flLearn);
                Button flReset=Btn("×",109,295,30,30,delegate{ResetMidiBind(B("Fader",index));},false);card.Controls.Add(flReset);
                hints.SetToolTip(flReset,"Сбросить только MIDI фейдера "+index);
                card.Controls.Add(L("ЭНКОДЕР",12,335,125,18,8,true,dim));
                knobApp[i]=Combo(10,357,130,26);card.Controls.Add(knobApp[i]);knobApp[i].AccessibleName="Приложение энкодера "+index;
                knobApp[i].TextChanged+=delegate{if(!refreshingCombos)ChangeTarget(B("Knob",index),knobApp[index-1].Text);};
                knobMode[i]=new ComboBox();knobMode[i].DropDownStyle=ComboBoxStyle.DropDownList;knobMode[i].Items.AddRange(new object[]{"Relative ±64","Absolute CC"});
                knobMode[i].BackColor=panelLight;knobMode[i].ForeColor=fg;knobMode[i].FlatStyle=FlatStyle.Flat;knobMode[i].SetBounds(10,391,130,26);
                knobMode[i].AccessibleName="Режим энкодера "+index;card.Controls.Add(knobMode[i]);knobMode[i].SelectedIndex=savedEncoderModes[i]==1?1:0;
                knobMode[i].SelectedIndexChanged+=delegate{B("Knob",index).LastValue=-1;knobPendingSteps[index-1]=0;MarkDirty();};
                knobMidi[i]=L(B("Knob",index).Info,10,423,130,19,8,false,dim);card.Controls.Add(knobMidi[i]);
                Button knLearn=Btn("Обучить K",10,449,94,30,delegate{ArmLearn(B("Knob",index));},false);card.Controls.Add(knLearn);
                Button knReset=Btn("×",109,449,30,30,delegate{ResetMidiBind(B("Knob",index));},false);card.Controls.Add(knReset);
                hints.SetToolTip(knReset,"Сбросить только MIDI энкодера "+index);
                card.Resize+=delegate{
                    int w=card.Width-20;
                    faderApp[index-1].Width=w;knobApp[index-1].Width=w;knobMode[index-1].Width=w;num.Width=w;
                    faderValue[index-1].Width=w;faderMidi[index-1].Width=w;knobMidi[index-1].Width=w;
                    faderLevel[index-1].Left=(card.Width-faderLevel[index-1].Width)/2;
                    flLearn.Width=w-35;flReset.Left=10+w-30;knLearn.Width=w-35;knReset.Left=10+w-30;
                };
            }
        }
        private DataGridView CreateButtonTab(string title,string kind,int count)
        {
            TabPage page=new TabPage(title);page.BackColor=dark;tabs.TabPages.Add(page);
            TableLayoutPanel container=new TableLayoutPanel();container.Dock=DockStyle.Fill;container.ColumnCount=1;container.RowCount=3;
            container.RowStyles.Add(new RowStyle(SizeType.Absolute,40));container.RowStyles.Add(new RowStyle(SizeType.Absolute,49));
            container.RowStyles.Add(new RowStyle(SizeType.Percent,100));page.Controls.Add(container);
            Label caption=L("Щелчок — выбрать  ·  двойной щелчок — играть  ·  правая кнопка — действия",8,0,1100,37,9,false,dim);caption.Dock=DockStyle.Fill;container.Controls.Add(caption,0,0);
            FlowLayoutPanel bar=new FlowLayoutPanel();bar.Dock=DockStyle.Fill;bar.WrapContents=false;bar.AutoScroll=true;bar.Padding=new Padding(3,2,0,3);container.Controls.Add(bar,0,1);
            Button load=Btn("+ Загрузить звук",0,0,153,34,delegate{ChooseSound(kind);},true);bar.Controls.Add(load);
            bar.Controls.Add(Btn("Обучить MIDI",0,0,132,34,delegate{LearnSelectedButton(kind);},false));
            bar.Controls.Add(Btn("Играть",0,0,99,34,delegate{PlaySelectedButton(kind);},false));
            bar.Controls.Add(Btn("Убрать звук",0,0,118,34,delegate{ClearSelectedFile(kind);},false));
            Button details=Btn("Таблица / режимы",0,0,163,34,delegate{},false);bar.Controls.Add(details);
            Panel body=new Panel();body.Dock=DockStyle.Fill;container.Controls.Add(body,0,2);
            FlowLayoutPanel pads=new FlowLayoutPanel();pads.Dock=DockStyle.Fill;pads.AutoScroll=true;pads.Padding=new Padding(0,5,4,5);body.Controls.Add(pads);
            DataGridView g=new DataGridView();g.Dock=DockStyle.Fill;g.BorderStyle=BorderStyle.None;g.Visible=false;body.Controls.Add(g);
            g.AllowUserToAddRows=false;g.AllowUserToDeleteRows=false;g.AllowUserToResizeRows=false;g.RowHeadersVisible=false;
            g.MultiSelect=false;g.SelectionMode=DataGridViewSelectionMode.FullRowSelect;g.BackgroundColor=dark;g.GridColor=panelLight;
            g.DefaultCellStyle.BackColor=panel;g.DefaultCellStyle.ForeColor=fg;g.DefaultCellStyle.SelectionBackColor=Color.FromArgb(36,77,76);
            g.DefaultCellStyle.SelectionForeColor=Color.White;g.DefaultCellStyle.Padding=new Padding(5);
            g.AlternatingRowsDefaultCellStyle.BackColor=Color.FromArgb(28,35,48);
            g.ColumnHeadersDefaultCellStyle.BackColor=panelLight;g.ColumnHeadersDefaultCellStyle.ForeColor=dim;g.EnableHeadersVisualStyles=false;
            g.ColumnHeadersHeight=40;g.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.DisableResizing;g.RowTemplate.Height=42;
            g.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;
            g.Columns.Add(new DataGridViewTextBoxColumn(){Name="num",HeaderText="#",FillWeight=35,ReadOnly=true,SortMode=DataGridViewColumnSortMode.NotSortable});
            g.Columns.Add(new DataGridViewTextBoxColumn(){Name="key",HeaderText="Кнопка",FillWeight=100,ReadOnly=true,SortMode=DataGridViewColumnSortMode.NotSortable});
            g.Columns.Add(new DataGridViewTextBoxColumn(){Name="midi",HeaderText="MIDI",FillWeight=130,ReadOnly=true,SortMode=DataGridViewColumnSortMode.NotSortable});
            DataGridViewComboBoxColumn act=new DataGridViewComboBoxColumn();act.Name="mode";act.HeaderText="Режим";act.FillWeight=110;act.FlatStyle=FlatStyle.Flat;
            act.Items.AddRange(new object[]{"Играть","Вкл/выкл","Стоп всё"});g.Columns.Add(act);
            g.Columns.Add(new DataGridViewTextBoxColumn(){Name="file",HeaderText="Звуковой файл",FillWeight=240,ReadOnly=true,SortMode=DataGridViewColumnSortMode.NotSortable});
            g.Columns.Add(new DataGridViewTextBoxColumn(){Name="info",HeaderText="Статус",FillWeight=135,ReadOnly=true,SortMode=DataGridViewColumnSortMode.NotSortable});
            g.CurrentCellDirtyStateChanged+=delegate{if(g.IsCurrentCellDirty)g.CommitEdit(DataGridViewDataErrorContexts.Commit);};
            g.DataError+=delegate(object sender,DataGridViewDataErrorEventArgs e){e.ThrowException=false;};
            g.CellValueChanged+=delegate(object sender,DataGridViewCellEventArgs e){
                if(initializing||e.RowIndex<0||e.ColumnIndex!=g.Columns["mode"].Index)return;
                B(kind,e.RowIndex+1).PlayMode=Convert.ToString(g.Rows[e.RowIndex].Cells["mode"].Value);MarkDirty();RefreshPad(B(kind,e.RowIndex+1));
            };
            g.KeyDown+=delegate(object sender,KeyEventArgs e){if(e.KeyCode==Keys.Delete){ClearSelectedFile(kind);e.Handled=true;}};
            details.Click+=delegate{g.Visible=!g.Visible;pads.Visible=!g.Visible;if(g.Visible)g.BringToFront();details.Text=g.Visible?"Площадки":"Таблица / режимы";};
            soundPads[kind]=new SoundPad[count];buttonGrids[kind]=g;
            for(int i=1;i<=count;i++)
            {
                int index=i;Binding binding=B(kind,i);
                string label=kind=="Main"?"Основная "+i.ToString("00"):"F"+((i-1)/4+1)+" · "+new[]{"M","S","R","SEL"}[(i-1)%4];
                g.Rows.Add(i,label,binding.Info,binding.PlayMode,SoundFileLabel(binding),"—");
                SoundPad pad=new SoundPad();pad.Badge=label.ToUpperInvariant();pad.AccessibleName=label;
                soundPads[kind][i-1]=pad;pads.Controls.Add(pad);
                pad.Click+=delegate{SelectPad(kind,index);};
                // Standard WinForms Button emits Click twice instead of DoubleClick; handle timing explicitly.
                DateTime lastClick=DateTime.MinValue;
                pad.MouseDown+=delegate(object sender,MouseEventArgs e){
                    if(e.Button!=MouseButtons.Left)return;
                    DateTime now=DateTime.UtcNow;
                    if((now-lastClick).TotalMilliseconds<=SystemInformation.DoubleClickTime){SelectPad(kind,index);PlayButton(B(kind,index));lastClick=DateTime.MinValue;}
                    else lastClick=now;
                };
                ContextMenuStrip menu=new ContextMenuStrip();
                menu.Items.Add("Играть / переключить",null,delegate{SelectPad(kind,index);PlayButton(B(kind,index));});
                menu.Items.Add("Загрузить звук…",null,delegate{SelectPad(kind,index);ChooseSound(kind);});
                menu.Items.Add("Обучить MIDI",null,delegate{ArmLearn(B(kind,index));});
                menu.Items.Add("Сбросить MIDI",null,delegate{ResetMidiBind(B(kind,index));});
                menu.Items.Add("Убрать звук",null,delegate{SelectPad(kind,index);ClearSelectedFile(kind);});pad.ContextMenuStrip=menu;
                RefreshPad(binding);
            }
            g.SelectionChanged+=delegate{foreach(SoundPad pad in soundPads[kind]){pad.Selected=g.CurrentRow!=null&&pad==soundPads[kind][g.CurrentRow.Index];pad.Invalidate();}};
            pads.Resize+=delegate{
                int columns=Math.Max(3,Math.Min(kind=="Main"?4:8,(pads.ClientSize.Width-24)/(kind=="Main"?230:148)));
                int width=Math.Max(120,(pads.ClientSize.Width-28)/columns-12);
                foreach(SoundPad pad in soundPads[kind]){pad.Width=width;pad.Height=kind=="Main"?126:110;}
            };
            SelectPad(kind,1);return g;
        }
        private string SoundFileLabel(Binding b)
        {
            if(String.IsNullOrEmpty(b.FileName))return "(нет звука)";
            return File.Exists(b.FileName)?Path.GetFileName(b.FileName):"Не найден: "+Path.GetFileName(b.FileName);
        }
        private void SelectPad(string kind,int index)
        {
            DataGridView g=buttonGrids[kind];g.CurrentCell=g.Rows[index-1].Cells[0];g.Rows[index-1].Selected=true;
            foreach(SoundPad pad in soundPads[kind]){pad.Selected=pad==soundPads[kind][index-1];pad.Invalidate();}
        }
        private void RefreshPad(Binding b)
        {
            if(!soundPads.ContainsKey(b.Kind))return;
            SoundPad pad=soundPads[b.Kind][b.Index-1];pad.Assigned=File.Exists(b.FileName);
            pad.SoundName=b.PlayMode=="Стоп всё"?"Остановить всё":String.IsNullOrEmpty(b.FileName)?"Добавить звук":Path.GetFileNameWithoutExtension(b.FileName);
            if(!String.IsNullOrEmpty(b.FileName)&&!pad.Assigned)pad.SoundName="Не найден: "+pad.SoundName;
            pad.Mapping=b.Number<0?"MIDI не назначен":b.Info;pad.Learning=learning==b;pad.Playing=sounds.IsPlaying(SoundIndex(b));
            hints.SetToolTip(pad,String.IsNullOrEmpty(b.FileName)?"Выберите площадку и загрузите звук":b.FileName+"\n"+b.PlayMode);
            pad.Invalidate();
        }
        private static int SoundIndex(Binding b){return b.Kind=="Main"?b.Index:100+b.Index;}
        private void StopAllSounds()
        {
            sounds.StopAll();RefreshAllPads();SetStatus("Все звуки остановлены");
            if(playingLabel!=null)playingLabel.Text="Звуков: 0";
        }
        private void RefreshAllPads(){foreach(Binding b in bindings)if(b.Kind=="Main"||b.Kind=="Track")RefreshPad(b);}
        private void RefreshPlayback()
        {
            foreach(Binding b in bindings)
            {
                if(b.Kind!="Main"&&b.Kind!="Track")continue;
                SoundPad pad=soundPads[b.Kind][b.Index-1];bool playing=sounds.IsPlaying(SoundIndex(b));
                if(pad.Playing!=playing){pad.Playing=playing;pad.Invalidate();}
            }
        }
        private void ChangeTarget(Binding b,string target)
        {
            if(b.Target==target)return;b.Target=target;b.PendingPct=-1;b.CurrentPct=-1;b.LastValue=-1;
            if(b.Kind=="Knob")knobPendingSteps[b.Index-1]=0;
            MarkDirty();
        }
        private void MarkDirty(){if(initializing||previewMode)return;settingsDirty=true;lastSaveEdit=DateTime.UtcNow;}
        private void CancelLearn()
        {
            if(learning==null)return;learning=null;learn.Clear();RefreshAllPads();
            SetStatus("Обучение отменено");
        }
        private int SelectedIndex(string kind)
        {
            DataGridView g=buttonGrids[kind]; return g.CurrentRow==null?-1:g.CurrentRow.Index+1;
        }
        private void ChooseSound(string kind)
        {
            int i=SelectedIndex(kind); if(i<0) return;
            using(OpenFileDialog dlg=new OpenFileDialog())
            {
                dlg.Title="Звук для кнопки " + i; dlg.Filter="Звуковые файлы (*.wav;*.mp3;*.wma)|*.wav;*.mp3;*.wma|Все файлы (*.*)|*.*";
                if(dlg.ShowDialog(this)!=DialogResult.OK) return;
                sounds.Stop(SoundIndex(B(kind,i)));
                B(kind,i).FileName=dlg.FileName;
                RefreshPad(B(kind,i));
                buttonGrids[kind].Rows[i-1].Cells["file"].Value=Path.GetFileName(dlg.FileName);
                if(SaveSettings())SetStatus("Звук загружен: "+Path.GetFileName(dlg.FileName));
            }
        }
        private void ClearSelectedFile(string kind)
        {
            int i=SelectedIndex(kind); if(i<0) return;
            sounds.Stop(SoundIndex(B(kind,i)));
            B(kind,i).FileName="";buttonGrids[kind].Rows[i-1].Cells["file"].Value="(нет звука)";RefreshPad(B(kind,i));SaveSettings();
        }
        private void PlaySelectedButton(string kind)
        {
            int i=SelectedIndex(kind);if(i>0) PlayButton(B(kind,i));
        }
        private void LearnSelectedButton(string kind)
        {
            int i=SelectedIndex(kind);if(i>0) ArmLearn(B(kind,i));
        }
        private void PlayButton(Binding b)
        {
            if(b.PlayMode=="Стоп всё") {StopAllSounds();SetButtonStatus(b,"Все остановлено");return;}
            if(String.IsNullOrWhiteSpace(b.FileName)) { SetButtonStatus(b,"Нет звука"); return; }
            try { sounds.Play(SoundIndex(b),b.FileName,b.PlayMode=="Вкл/выкл");RefreshPad(b);
                  SetButtonStatus(b,Path.GetFileName(b.FileName)); }
            catch(Exception ex) {SetButtonStatus(b,"Ошибка воспроизведения"); SetStatus(ex.Message);}
        }
        private void SetButtonStatus(Binding b,string text)
        {
            if(buttonGrids.ContainsKey(b.Kind) && b.Index<=buttonGrids[b.Kind].Rows.Count)
                buttonGrids[b.Kind].Rows[b.Index-1].Cells["info"].Value=text;
            SetStatus(b.Kind+" "+b.Index+" → "+text);
        }
        private void RefreshPorts()
        {
            if(previewMode){SetStatus("В предпросмотре устройства не подключаются");return;}
            if(midi.IsOpen){SetStatus("Отключите MIDI перед обновлением портов");return;}
            try
            {
                HashSet<string> selected=new HashSet<string>();
                foreach(object item in portList.CheckedItems)selected.Add(item.ToString());
                List<string> names=MidiPorts.Enumerate();portList.Items.Clear();
                for(int i=0;i<names.Count;i++)portList.Items.Add(names[i],selected.Contains(names[i])||names[i].IndexOf("SMC",StringComparison.OrdinalIgnoreCase)>=0);
                SetStatus(names.Count==0?"MIDI-входы не найдены. Подключите контроллер и нажмите «Обновить».":"Найдено MIDI-входов: "+names.Count);
            }
            catch(Exception ex){SetStatus("Не удалось получить MIDI-входы: "+ex.Message);}
        }
        private void ToggleMidi()
        {
            if(previewMode)return;
            if(midi.IsOpen)
            {
                midi.Close();CancelLearn();
                foreach(Binding b in bindings){b.ButtonDown=false;b.PendingPct=-1;b.LastValue=-1;}
                Array.Clear(knobPendingSteps,0,knobPendingSteps.Length);
                connectButton.Text="Подключить MIDI";connectionLabel.Text="Не подключён";connectionLabel.ForeColor=dim;portList.Enabled=true;return;
            }
            List<int> ids=new List<int>();List<string> names=new List<string>();
            for(int i=0;i<portList.Items.Count;i++){names.Add(portList.Items[i].ToString());if(portList.GetItemChecked(i))ids.Add(i);}
            if(ids.Count==0){SetStatus("Отметьте хотя бы один MIDI-вход");return;}
            try{midi.Open(ids,names);}
            catch(Exception ex){SetStatus(ex.Message);if(!midi.IsOpen)return;}
            connectButton.Text="Отключить MIDI";connectionLabel.Text="Подключено: "+midi.OpenCount;connectionLabel.ForeColor=cyan;portList.Enabled=false;
        }
        private void RefreshApps(bool showStatus)
        {
            if(initializing&&faderApp[0]==null)return;
            try
            {
                if(!previewMode)apps=WindowsAudio.ListApps();
                refreshingCombos=true;
                for(int i=0;i<8;i++)
                {
                    RefreshCombo(faderApp[i],B("Fader",i+1).Target);
                    RefreshCombo(knobApp[i],B("Knob",i+1).Target);
                }
                if(showStatus)SetStatus("Аудиосессии: "+Math.Max(0,apps.Count-1)+". Включите звук в приложении, чтобы оно появилось здесь.");
            }
            catch(Exception ex){if(showStatus)SetStatus("Windows Audio: "+ex.Message);}
            finally{refreshingCombos=false;}
        }
        private void RefreshCombo(ComboBox c,string current)
        {
            if(c==null)return;
            c.BeginUpdate();
            try
            {
                c.Items.Clear();c.Items.Add("");foreach(string name in apps)c.Items.Add(name);
                if(!String.IsNullOrEmpty(current)&&!c.Items.Contains(current))c.Items.Add(current);
                c.Text=current;
            }
            finally{c.EndUpdate();}
        }
        private void ResetMidiBind(Binding b)
        {
            if(b==null)return;
            if(learning==b) {learning=null;learn.Clear();}
            b.Source="";
            b.Port="";
            b.Channel=1;
            b.Number=-1;
            b.LastValue=-1;
            b.PendingPct=-1;
            b.CurrentPct=-1;
            b.ButtonDown=false;
            if(b.Kind=="Fader") faderMidi[b.Index-1].Text=b.Info;
            if(b.Kind=="Knob") knobMidi[b.Index-1].Text=b.Info;
            if(b.Kind=="Knob")knobPendingSteps[b.Index-1]=0;
            if(b.Kind=="Main"||b.Kind=="Track") {buttonGrids[b.Kind].Rows[b.Index-1].Cells["midi"].Value=b.Info;RefreshPad(b);}
            // Keep the assigned Windows application and current volume unchanged.
            if(SaveSettings())SetStatus("Сброшена MIDI-привязка только "+b.Kind+" "+b.Index+". Выбор приложения сохранён.");
        }

        private void ArmLearn(Binding b)
        {
            if(!midi.IsOpen){MessageBox.Show("Сначала открой MIDI-входы.","MIDI Learn");return;}
            learning=b;learn.Clear();learnStart=DateTime.UtcNow;RefreshAllPads();
            MidiEvent trash; while(incoming.TryDequeue(out trash)){}
            SetStatus("ОБУЧЕНИЕ: "+b.Kind+" "+b.Index+" • "+(b.Kind=="Fader"?"Плавно проведи фейдер минимум на 20%":b.Kind=="Knob"?"Поверни энкодер в обе стороны":"Нажми нужную кнопку"));
        }
        private void Tick(object sender,EventArgs e)
        {
            DateTime now=DateTime.UtcNow;
            if(learning!=null&&(now-learnStart).TotalSeconds>20){CancelLearn();SetStatus("Время обучения вышло. Нажмите «Обучить» и повторите.");}
            if(settingsDirty&&(now-lastSaveEdit).TotalMilliseconds>900)
            {
                settingsDirty=false;SaveSettings();
            }
            if((now-lastPlaybackRefresh).TotalMilliseconds>=250)
            {
                lastPlaybackRefresh=now;sounds.ReapFinished();
                if(Visible){RefreshPlayback();string count="Звуков: "+sounds.ActiveCount;if(playingLabel.Text!=count)playingLabel.Text=count;}
            }
            if(midi.TakeDroppedEventCount()>0)
            {
                foreach(Binding b in bindings)b.ButtonDown=false;
                SetStatus("Перегрузка MIDI: часть событий пропущена");
            }
            MidiEvent ev;int processed=0;string latestEvent=null;
            while(processed++<360&&incoming.TryDequeue(out ev))
            {
                int st=(int)(ev.Raw&255),d1=(int)((ev.Raw>>8)&127),d2=(int)((ev.Raw>>16)&127);
                int hi=st&240,channel=(st&15)+1;
                string source=hi==0xB0?"CC":hi==0xE0?"PB":hi==0x90||hi==0x80?"Note":"";
                if(source.Length==0)continue;
                int number=source=="PB"?0:d1,raw=source=="PB"?d1|(d2<<7):d2;
                int value=source=="PB"?(int)Math.Round(raw*127.0/16383.0):raw;
                bool on=hi==0x90?d2>0:hi==0x80?false:value>0;
                latestEvent=ev.Device+"  ·  "+source+" "+number+"  ·  CH "+channel+"  ·  "+raw;
                if(learning!=null){HandleLearn(ev.Device,source,channel,number,value,on);continue;}
                foreach(Binding b in bindings)
                {
                    if(b.Number!=number||b.Channel!=channel||b.Source!=source||b.Port!=ev.Device)continue;
                    if(b.Kind=="Fader")
                    {
                        int pct=Clamp((int)Math.Round(value*100.0/127.0));b.PendingPct=pct;
                        if(Visible){faderLevel[b.Index-1].Value=pct;faderValue[b.Index-1].Text=pct+"%";}
                    }
                    else if(b.Kind=="Knob")ProcessKnob(b,value);
                    else
                    {
                        bool pressed=(hi==0x90&&d2>0)||(hi==0xB0&&d2>=64);
                        if(pressed&&!b.ButtonDown)PlayButton(b);b.ButtonDown=pressed;
                    }
                }
            }
            if(latestEvent!=null&&Visible)liveLabel.Text=latestEvent;
            foreach(Binding b in bindings)
            {
                if(b.Kind=="Fader")
                {
                    if(b.PendingPct<0||b.CurrentPct==b.PendingPct||(now-b.LastApplied).TotalMilliseconds<65)continue;
                    int pct=b.PendingPct;b.LastApplied=now;b.PendingPct=-1;
                    if(ApplyVolume(b,pct))b.CurrentPct=pct;
                }
                else if(b.Kind=="Knob"&&knobPendingSteps[b.Index-1]!=0&&(now-b.LastApplied).TotalMilliseconds>=65)
                {
                    int steps=knobPendingSteps[b.Index-1];knobPendingSteps[b.Index-1]=0;b.LastApplied=now;
                    ApplyKnobSteps(b,steps);
                }
            }
        }
        private void HandleLearn(string port,string source,int channel,int number,int value,bool on)
        {
            if(learning==null)return;
            if((DateTime.UtcNow-learnStart).TotalSeconds>20){CancelLearn();SetStatus("Время обучения вышло. Повторите.");return;}
            bool button=learning.Kind=="Main"||learning.Kind=="Track";
            if(button&&((source!="Note"&&source!="CC")||!on||(source=="CC"&&value<64)))return;
            if(!button&&(source!="CC"&&source!="PB"))return;
            string key=port+"|"+source+"|"+channel+"|"+number;
            LearnData d;
            if(!learn.TryGetValue(key,out d)) {d=new LearnData(){Source=source,Port=port,Channel=channel,Number=number};learn[key]=d;}
            d.Add(value);
            if(button || (learning.Kind=="Knob"&&d.Count>=2) ||
                (learning.Kind=="Fader"&&d.Count>=3&&(d.Max-d.Min>=10)))
            {
                learning.Source=source;learning.Port=port;learning.Channel=channel;learning.Number=number;
                learning.LastValue=-1;learning.ButtonDown=false;
                SetStatus("Обучено: "+learning.Kind+" "+learning.Index+" → "+learning.Info+" / "+port);
                if(learning.Kind=="Fader")faderMidi[learning.Index-1].Text=learning.Info;
                if(learning.Kind=="Knob")knobMidi[learning.Index-1].Text=learning.Info;
                if(button)buttonGrids[learning.Kind].Rows[learning.Index-1].Cells["midi"].Value=learning.Info;
                learning=null;learn.Clear();RefreshAllPads();SaveSettings();
            }
        }
        private void SetStripVolume(Binding b,int pct)
        {
            b.PendingPct=Clamp(pct);faderValue[b.Index-1].Text=b.PendingPct+"%";
        }
        private bool ApplyVolume(Binding b,int pct)
        {
            if(String.IsNullOrWhiteSpace(b.Target))return false;
            if(previewMode)return true;
            try
            {
                if(WindowsAudio.SetVolume(b.Target,pct)>0)return true;
                AudioError("Нет активной аудиосессии: "+b.Target+". Включите звук в приложении.");
            }
            catch(Exception ex){AudioError("Громкость "+b.Target+": "+ex.Message);}
            return false;
        }
        private void AudioError(string message)
        {
            if((DateTime.UtcNow-lastAudioError).TotalSeconds<2)return;
            lastAudioError=DateTime.UtcNow;SetStatus(message);
        }
        private void ProcessKnob(Binding b,int v)
        {
            int index=b.Index-1,steps=0;
            if(knobMode[index].SelectedIndex==0)
            {
                if(v>=1&&v<=63)steps=Math.Min(8,v);
                else if(v>=65&&v<=127)steps=-Math.Min(8,v-64);
            }
            else
            {
                if(b.LastValue>=0){int delta=v-b.LastValue;if(Math.Abs(delta)<=25)steps=delta;}
                b.LastValue=v;
            }
            if(steps==0||String.IsNullOrWhiteSpace(b.Target))return;
            // Aggregate bursts: one Core Audio read/write per encoder per 65 ms.
            knobPendingSteps[index]=Math.Max(-100,Math.Min(100,knobPendingSteps[index]+steps));
        }
        private void ApplyKnobSteps(Binding b,int steps)
        {
            if(previewMode)return;
            try
            {
                int? current=WindowsAudio.GetVolume(b.Target);
                if(!current.HasValue){AudioError("Нет активной аудиосессии: "+b.Target);return;}
                int newValue=Clamp(current.Value+steps*2);
                if(WindowsAudio.SetVolume(b.Target,newValue)>0&&Visible)knobMidi[b.Index-1].Text=newValue+"%  ·  "+b.Info;
            }
            catch(Exception ex){AudioError("Энкодер: "+ex.Message);}
        }
        private void SetStatus(string text){if(actionLabel!=null)actionLabel.Text="  "+DateTime.Now.ToString("HH:mm:ss")+"  •  "+text;}
        private void SyncMappings()
        {
            for(int i=0;i<8;i++)
            {
                faderApp[i].Text=B("Fader",i+1).Target;
                knobApp[i].Text=B("Knob",i+1).Target;
                faderMidi[i].Text=B("Fader",i+1).Info;
                knobMidi[i].Text=B("Knob",i+1).Info;
            }
        }
        // Keep the previous successful save for recovery; never overwrite an unreadable file silently.
        private string settingsWarning = "";
        private bool settingsSaveBlocked;
        private bool settingsRecoveredFromBackup;

        private bool SaveSettings()
        {
            if(previewMode)return true;
            settingsDirty=false;
            if (settingsSaveBlocked)
            {
                SetStatus(settingsWarning);
                return false;
            }
            string temporary = configPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(configPath));
                XmlDocument x = new XmlDocument();
                XmlElement root = x.CreateElement("audioDeck");
                root.SetAttribute("version", "1.3");
                x.AppendChild(root);
                foreach (Binding b in bindings)
                {
                    XmlElement node = x.CreateElement("binding");
                    node.SetAttribute("kind", b.Kind);
                    node.SetAttribute("index", b.Index.ToString(CultureInfo.InvariantCulture));
                    node.SetAttribute("source", b.Source);
                    node.SetAttribute("port", b.Port);
                    node.SetAttribute("channel", b.Channel.ToString(CultureInfo.InvariantCulture));
                    node.SetAttribute("number", b.Number.ToString(CultureInfo.InvariantCulture));
                    node.SetAttribute("target", b.Target);
                    node.SetAttribute("file", PortableSoundPath(b.FileName));
                    node.SetAttribute("play", b.PlayMode);
                    root.AppendChild(node);
                }
                for (int i = 0; i < 8; i++)
                {
                    XmlElement kn = x.CreateElement("encoderMode");
                    kn.SetAttribute("index", (i + 1).ToString(CultureInfo.InvariantCulture));
                    int mode = knobMode[i] == null ? savedEncoderModes[i] : knobMode[i].SelectedIndex;
                    kn.SetAttribute("value", mode == 1 ? "1" : "0");
                    root.AppendChild(kn);
                }
                // Write and flush before replacing the live file, on the same filesystem.
                using (FileStream stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    x.Save(stream);
                    stream.Flush(true);
                }
                if (File.Exists(configPath))
                {
                    if (settingsRecoveredFromBackup)
                    {
                        // Retain the damaged original and the valid recovery copy separately.
                        string damaged = configPath + ".corrupt-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) + "-" + Guid.NewGuid().ToString("N");
                        File.Copy(configPath, damaged, false);
                        File.Replace(temporary, configPath, null);
                    }
                    else File.Replace(temporary, configPath, configPath + ".bak");
                }
                else File.Move(temporary, configPath);
                settingsRecoveredFromBackup = false;
                return true;
            }
            catch (Exception ex)
            {
                SetStatus("Ошибка сохранения: " + ex.Message);
                return false;
            }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
            }
        }

        private static XmlDocument ReadSettingsFile(string path)
        {
            XmlReaderSettings options = new XmlReaderSettings();
            options.DtdProcessing = DtdProcessing.Prohibit;
            options.XmlResolver = null;
            options.MaxCharactersInDocument = 2 * 1024 * 1024;
            XmlDocument document = new XmlDocument();
            document.XmlResolver = null;
            using (XmlReader reader = XmlReader.Create(path, options)) document.Load(reader);
            if (document.DocumentElement == null || document.DocumentElement.Name != "audioDeck")
                throw new XmlException("Ожидался файл настроек Audio Deck.");
            return document;
        }

        private static string ResolveSoundPath(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) return "";
            try
            {
                return Path.GetFullPath(Path.IsPathRooted(value) ? value : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, value));
            }
            catch (ArgumentException) { return ""; }
            catch (NotSupportedException) { return ""; }
            catch (PathTooLongException) { return ""; }
        }

        private static string PortableSoundPath(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) return "";
            string full = ResolveSoundPath(value);
            if (full.Length == 0) return value;
            string root = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            // Files bundled with the application remain usable after moving its folder.
            return full.StartsWith(root, StringComparison.OrdinalIgnoreCase) ? full.Substring(root.Length) : full;
        }

        private void LoadSettings()
        {
            settingsWarning = "";
            settingsSaveBlocked = false;
            settingsRecoveredFromBackup = false;
            XmlDocument x;
            string recovery = configPath + ".bak";
            if (!File.Exists(configPath) && !File.Exists(recovery)) return;
            try { x = ReadSettingsFile(configPath); }
            catch (Exception)
            {
                try
                {
                    x = ReadSettingsFile(recovery);
                    settingsRecoveredFromBackup = true;
                    settingsWarning = "Настройки восстановлены из settings.xml.bak. Повреждённый файл будет сохранён отдельно.";
                }
                catch (Exception)
                {
                    settingsSaveBlocked = true;
                    settingsWarning = "Настройки повреждены: сохранение приостановлено. Сохрани копии и переименуй settings.xml и settings.xml.bak в папке " + Path.GetDirectoryName(configPath) + ", затем перезапусти программу.";
                    return;
                }
            }
            int invalid = 0;
            foreach (XmlNode kn in x.SelectNodes("/audioDeck/encoderMode"))
            {
                int k, mode;
                if (Int32.TryParse(Attr(kn, "index"), out k) && k >= 1 && k <= 8 &&
                    Int32.TryParse(Attr(kn, "value"), out mode) && (mode == 0 || mode == 1))
                    savedEncoderModes[k - 1] = mode;
                else invalid++;
            }
            HashSet<string> seen = new HashSet<string>();
            foreach (XmlNode node in x.SelectNodes("/audioDeck/binding"))
            {
                string kind = Attr(node, "kind");
                int index;
                if (!Int32.TryParse(Attr(node, "index"), out index)) { invalid++; continue; }
                Binding b = B(kind, index);
                if (b == null || !seen.Add(kind + ":" + index.ToString(CultureInfo.InvariantCulture))) { invalid++; continue; }
                b.Target = Attr(node, "target").Trim();
                b.FileName = ResolveSoundPath(Attr(node, "file"));
                string play = Attr(node, "play");
                b.PlayMode = play == "Вкл/выкл" || play == "Стоп всё" ? play : "Играть";
                string source = Attr(node, "source");
                int channel, number;
                bool continuous = kind == "Fader" || kind == "Knob";
                bool validSource = source == "CC" || (continuous ? source == "PB" : source == "Note");
                bool validChannel = Int32.TryParse(Attr(node, "channel"), out channel) && channel >= 1 && channel <= 16;
                if (!Int32.TryParse(Attr(node, "number"), out number)) number = -1;
                bool valid = validSource && validChannel && number >= 0 && number <= 127 && (source != "PB" || number == 0);
                b.Source = valid ? source : "";
                b.Port = valid ? Attr(node, "port") : "";
                b.Channel = valid ? channel : 1;
                b.Number = valid ? number : -1;
                if (!valid && (source.Length > 0 || number >= 0)) invalid++;
            }
            if (invalid > 0)
                settingsWarning += (settingsWarning.Length > 0 ? " " : "") + "Пропущены некорректные записи настроек: " + invalid.ToString(CultureInfo.InvariantCulture) + ". Остальные назначения загружены.";
        }

        private static string Attr(XmlNode node, string name)
        {
            XmlAttribute a = node.Attributes == null ? null : node.Attributes[name];
            return a == null ? "" : a.Value;
        }
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += delegate(object s,ThreadExceptionEventArgs e){MessageBox.Show(e.Exception.ToString(),"M-VAVE Audio Deck");};
            bool preview=Array.IndexOf(Environment.GetCommandLineArgs(),"--preview")>=0;
            using(Mutex single=new Mutex(false,"Local\\MVAVE.AudioDeck.v1"))
            {
                bool acquired=false;
                try
                {
                    if(!preview)
                    {
                        try{acquired=single.WaitOne(0,false);}catch(AbandonedMutexException){acquired=true;}
                        if(!acquired){MessageBox.Show("Audio Deck уже запущен. Откройте его значок в системном трее.","M-VAVE Audio Deck");return;}
                    }
                    Application.Run(new DeckForm(preview));
                }
                finally{if(acquired)single.ReleaseMutex();}
            }
        }
    }

}
