using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MVaveAudioDeck
{
    internal static class DeckPalette
    {
        public static readonly Color Background = Color.FromArgb(15, 19, 28);
        public static readonly Color Surface = Color.FromArgb(24, 30, 42);
        public static readonly Color Raised = Color.FromArgb(34, 42, 57);
        public static readonly Color Border = Color.FromArgb(47, 58, 76);
        public static readonly Color Text = Color.FromArgb(236, 242, 250);
        public static readonly Color Muted = Color.FromArgb(151, 166, 189);
        public static readonly Color Accent = Color.FromArgb(92, 229, 192);
        public static readonly Color Danger = Color.FromArgb(255, 132, 145);
        public static GraphicsPath Round(Rectangle r, int radius)
        {
            GraphicsPath p = new GraphicsPath();
            int d = Math.Min(radius * 2, Math.Min(r.Width, r.Height));
            if (d < 2) { p.AddRectangle(r); return p; }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right-d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right-d, r.Bottom-d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom-d, d, d, 90, 90); p.CloseFigure(); return p;
        }
    }
    internal class DeckCard : Panel
    {
        public DeckCard() { DoubleBuffered = true; BackColor = DeckPalette.Surface; }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen pen = new Pen(DeckPalette.Border))
            using (GraphicsPath p = DeckPalette.Round(new Rectangle(0,0,Width-1,Height-1),10))
                e.Graphics.DrawPath(pen,p);
        }
    }
    internal class DeckButton : Button
    {
        public bool Primary;
        public bool Danger;
        private bool hover;
        public DeckButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            FlatStyle=FlatStyle.Flat; FlatAppearance.BorderSize=0; Cursor=Cursors.Hand;
            Font=new Font("Segoe UI",9,FontStyle.Bold); ForeColor=DeckPalette.Text;
        }
        protected override void OnMouseEnter(EventArgs e) { hover=true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover=false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent == null ? DeckPalette.Background : Parent.BackColor);
            e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            Color bg=Primary ? DeckPalette.Accent : Danger ? Color.FromArgb(66,36,48) : DeckPalette.Raised;
            if (hover && Enabled) bg=ControlPaint.Light(bg,0.12f);
            using(GraphicsPath p=DeckPalette.Round(new Rectangle(0,0,Width-1,Height-1),7))
            using(SolidBrush b=new SolidBrush(bg)) e.Graphics.FillPath(b,p);
            Color text=!Enabled ? DeckPalette.Muted : Primary ? DeckPalette.Background : Danger ? DeckPalette.Danger : ForeColor;
            TextRenderer.DrawText(e.Graphics,Text,Font,ClientRectangle,text,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
            if(Focused && ShowFocusCues) ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(4,4,Width-8,Height-8),text,bg);
        }
    }
    internal sealed class DeckFader : Control
    {
        private int value=50;
        public event EventHandler Scroll;
        public int Value { get { return value; } set { int v=Math.Max(0,Math.Min(100,value)); if(this.value!=v) {this.value=v;Invalidate();} } }
        public DeckFader()
        {
            SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.Selectable,true);
            Size=new Size(76,185); Cursor=Cursors.Hand; TabStop=true; AccessibleRole=AccessibleRole.Slider;
        }
        private void Change(int v) { Value=v; if(Scroll!=null) Scroll(this,EventArgs.Empty); }
        private void FromMouse(int y) { Change((int)Math.Round((Height-18-y)*100.0/Math.Max(1,Height-36))); }
        protected override void OnMouseDown(MouseEventArgs e) {base.OnMouseDown(e); if(e.Button==MouseButtons.Left){Focus(); Capture=true;FromMouse(e.Y);} }
        protected override void OnMouseMove(MouseEventArgs e) {base.OnMouseMove(e);if(Capture && e.Button==MouseButtons.Left) FromMouse(e.Y);}
        protected override void OnMouseUp(MouseEventArgs e) {Capture=false;base.OnMouseUp(e);}
        protected override void OnMouseWheel(MouseEventArgs e) {base.OnMouseWheel(e);Change(Value+Math.Sign(e.Delta)*2);}
        protected override bool IsInputKey(Keys keyData) {return keyData==Keys.Up||keyData==Keys.Down||keyData==Keys.Home||keyData==Keys.End||base.IsInputKey(keyData);}
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Up||e.KeyCode==Keys.Down||e.KeyCode==Keys.Home||e.KeyCode==Keys.End)
            {Change(e.KeyCode==Keys.Home?0:e.KeyCode==Keys.End?100:Value+(e.KeyCode==Keys.Up?1:-1));e.Handled=true;}
            base.OnKeyDown(e);
        }
        protected override void OnGotFocus(EventArgs e){Invalidate();base.OnGotFocus(e);}
        protected override void OnLostFocus(EventArgs e){Invalidate();base.OnLostFocus(e);}
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            int x=Width/2, top=18, bottom=Height-18, y=bottom-(int)((bottom-top)*Value/100.0);
            using(Pen tick=new Pen(DeckPalette.Border))
                for(int i=0;i<=10;i++){int ty=top+(bottom-top)*i/10;e.Graphics.DrawLine(tick,x-26,ty,x-17,ty);e.Graphics.DrawLine(tick,x+17,ty,x+26,ty);}
            using(Pen rail=new Pen(DeckPalette.Background,6)) e.Graphics.DrawLine(rail,x,top,x,bottom);
            if(y<bottom) using(Pen level=new Pen(DeckPalette.Accent,4))e.Graphics.DrawLine(level,x,bottom,x,y);
            Rectangle thumb=new Rectangle(x-16,y-10,32,20);
            using(GraphicsPath p=DeckPalette.Round(thumb,4))
            using(SolidBrush b=new SolidBrush(Focused?DeckPalette.Accent:Color.FromArgb(209,220,235))) e.Graphics.FillPath(b,p);
            using(Pen line=new Pen(DeckPalette.Surface,2))e.Graphics.DrawLine(line,x-9,y,x+9,y);
        }
    }
    internal sealed class SoundPad : Button
    {
        public string Badge="01", SoundName="Добавить звук", Mapping="MIDI не назначен";
        public bool Selected, Playing, Assigned, Learning;
        private bool hover;
        public SoundPad()
        {
            SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);
            FlatStyle=FlatStyle.Flat; FlatAppearance.BorderSize=0; Cursor=Cursors.Hand;
            Size=new Size(230,125); Margin=new Padding(6); Font=new Font("Segoe UI",11,FontStyle.Bold);
        }
        protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
        protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent==null?DeckPalette.Background:Parent.BackColor);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            Color bg=Playing?Color.FromArgb(27,66,61):hover?DeckPalette.Raised:DeckPalette.Surface;
            Color accent=Learning?Color.FromArgb(255,199,115):DeckPalette.Accent;
            using(GraphicsPath p=DeckPalette.Round(new Rectangle(1,1,Width-3,Height-3),10))
            {using(SolidBrush b=new SolidBrush(bg))e.Graphics.FillPath(b,p);using(Pen pen=new Pen(Selected||Playing||Learning?accent:DeckPalette.Border,Selected?2:1))e.Graphics.DrawPath(pen,p);}
            using(Font small=new Font("Segoe UI",8,FontStyle.Bold))
            {
                TextRenderer.DrawText(e.Graphics,Badge,small,new Rectangle(15,12,Width-65,20),Selected?accent:DeckPalette.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter);
                using(SolidBrush icon=new SolidBrush(Playing?accent:DeckPalette.Muted))
                {
                    if(Playing)e.Graphics.FillRectangle(icon,Width-32,17,9,9);
                    else if(Assigned)e.Graphics.FillPolygon(icon,new[]{new Point(Width-32,16),new Point(Width-32,28),new Point(Width-22,22)});
                    else using(Pen plus=new Pen(DeckPalette.Muted,1.5f)){e.Graphics.DrawLine(plus,Width-32,22,Width-22,22);e.Graphics.DrawLine(plus,Width-27,17,Width-27,27);}
                }
                TextRenderer.DrawText(e.Graphics,Learning?"Ожидание MIDI…":Mapping,small,new Rectangle(15,Height-31,Width-30,19),Learning?accent:DeckPalette.Muted,TextFormatFlags.Left|TextFormatFlags.EndEllipsis|TextFormatFlags.VerticalCenter);
            }
            TextRenderer.DrawText(e.Graphics,SoundName,Font,new Rectangle(15,39,Width-30,Height-72),Assigned?DeckPalette.Text:DeckPalette.Muted,TextFormatFlags.Left|TextFormatFlags.WordBreak|TextFormatFlags.EndEllipsis);
            if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(7,7,Width-14,Height-14));
        }
    }
}
