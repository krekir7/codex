ТЕСТЫ ДЛЯ РАЗРАБОТЧИКА
=====================
Пользователю не нужно запускать эти файлы для работы Audio Deck.

SettingsTests.cs — reflection-проверки настроек, не создаёт окно и не требует MIDI.
Компиляция с Mono:
  mcs -langversion:5 -r:System.Windows.Forms -r:System.Drawing -r:System.Xml -out:SettingsTests.exe SettingsTests.cs
Запуск:
  mono SettingsTests.exe ../MVAVE_Audio_Deck.exe

UiTests.cs — окно в режиме предпросмотра (без подключения MIDI/CoreAudio),
проверки взаимодействия; принимает путь к EXE и необязательную папку снимков.
  mcs -langversion:5 -r:System.Windows.Forms -r:System.Drawing -out:UiTests.exe UiTests.cs
Для разрешения встроенных Demo_Sounds разместите UiTests.exe рядом с EXE приложения.
На Linux нужен работающий X-сервер или Xvfb (DISPLAY).
  mono UiTests.exe /полный/путь/MVAVE_Audio_Deck.exe /папка/снимков

CoreTests.cs + CoreNativeStub.c — проверки MIDI и SoundBoard с нативной заглушкой.
Нужно gcc и Mono на Linux. Работайте в ОТДЕЛЬНОЙ временной папке:
1. Скопируйте туда готовый MVAVE_Audio_Deck.exe и файлы этих двух тестов.
2. gcc -shared -fPIC -O2 -o libcoretest.so CoreNativeStub.c
3. mcs -langversion:5 -out:CoreTests.exe CoreTests.cs
4. Рядом с копией приложения создайте MVAVE_Audio_Deck.exe.config:
   <configuration><dllmap dll="winmm.dll" target="/полный/путь/libcoretest.so"/></configuration>
5. Рядом с CoreTests.exe создайте CoreTests.exe.config:
   <configuration><dllmap dll="core_test_native" target="/полный/путь/libcoretest.so"/></configuration>
6. mono CoreTests.exe ./MVAVE_Audio_Deck.exe

Заглушка проверяет логику, НЕ звук, драйверы или авторизацию.
НЕ помещайте её в рабочую папку Windows, не распространяйте вместо winmm.dll.
В поставляемом приложении нет нативных тестовых DLL, SO или dllmap-конфигураций.
