using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

internal static class UiTests
{
    private const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    private static int passed;
    private static string captureDirectory;
    private static object Field(object obj, string name) { return obj.GetType().GetField(name, Private).GetValue(obj); }
    private static void SetField(object obj, string name, object value) { obj.GetType().GetField(name, Private).SetValue(obj, value); }
    private static object Call(object obj, string name, params object[] args) { return obj.GetType().GetMethod(name, Private).Invoke(obj, args); }
    private static void Check(bool condition, string name) { if (!condition) throw new Exception(name); Console.WriteLine("PASS " + name); passed++; }
    private static object Bind(object form, string kind, int index) { return Call(form, "B", kind, index); }
    private static string Target(object binding) { return (string)binding.GetType().GetField("Target").GetValue(binding); }
    private static void Pump() { for(int i=0;i<5;i++) Application.DoEvents(); }
    private static void Capture(Form form, string filename)
    {
        if(captureDirectory == null) return;
        string path = Path.Combine(captureDirectory, filename);
        Pump(); form.Refresh(); Pump();
        using(Bitmap bmp = new Bitmap(form.Width, form.Height))
        {
            using(Graphics graphics = Graphics.FromImage(bmp)) graphics.CopyFromScreen(form.Location, Point.Empty, form.Size);
            bmp.Save(path, ImageFormat.Png);
        }
        Console.WriteLine("SCREENSHOT " + path);
    }
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
            if(args.Length < 1) throw new ArgumentException("Usage: UiTests.exe <AudioDeck.exe> [screenshot-directory]");
            string app = Path.GetFullPath(args[0]);
            if(args.Length > 1) { captureDirectory=Path.GetFullPath(args[1]); Directory.CreateDirectory(captureDirectory); }
            Assembly asm = Assembly.LoadFrom(app);
            Type deckType = asm.GetType("MVaveAudioDeck.DeckForm", true);
            using(Form form = (Form)Activator.CreateInstance(deckType, new object[]{true}))
            {
                form.StartPosition = FormStartPosition.Manual; form.Location = new Point(20,20);
                form.Show(); Pump();
                TabControl tabs = (TabControl)Field(form, "tabs");
                Check(tabs.TabPages.Count == 5, "five navigation tabs");
                Check(((Array)Field(form,"faderLevel")).Length==8, "eight mixer faders");
                Capture(form,"mixer.png");
                string[] targets = new string[8];
                for(int i=0;i<8;i++) targets[i] = Target(Bind(form,"Fader",i+1));
                Call(form,"RefreshApps",false);
                bool same=true; for(int i=0;i<8;i++) same &= targets[i] == Target(Bind(form,"Fader",i+1));
                Check(same,"refreshing app choices preserves all targets");
                ComboBox[] combos=(ComboBox[])Field(form,"faderApp");
                combos[0].Text="custom.exe";
                Check(Target(Bind(form,"Fader",1))=="custom.exe", "editing app target updates binding");
                Call(form,"RefreshApps",false);
                Check(combos[0].Text=="custom.exe" && Target(Bind(form,"Fader",1))=="custom.exe", "custom target survives refresh");
                object fader = ((Array)Field(form,"faderLevel")).GetValue(0);
                PropertyInfo value=fader.GetType().GetProperty("Value");
                value.SetValue(fader,150,null); Check((int)value.GetValue(fader,null)==100,"fader clamps maximum");
                value.SetValue(fader,-10,null); Check((int)value.GetValue(fader,null)==0,"fader clamps minimum");
                Call(fader,"OnKeyDown",new KeyEventArgs(Keys.End)); Check((int)value.GetValue(fader,null)==100,"fader End key");
                Call(fader,"OnKeyDown",new KeyEventArgs(Keys.Down)); Check((int)value.GetValue(fader,null)==99,"fader Down key");
                Call(fader,"OnKeyDown",new KeyEventArgs(Keys.Home)); Check((int)value.GetValue(fader,null)==0,"fader Home key");
                tabs.SelectedIndex=1; Pump();
                IDictionary pads=(IDictionary)Field(form,"soundPads");
                Array mainPads=(Array)pads["Main"];
                Check(mainPads.Length==11, "eleven main sound pads");
                ((Button)mainPads.GetValue(2)).PerformClick();
                Check((int)Call(form,"SelectedIndex","Main")==3,"pad click selects associated grid row");
                Check((bool)mainPads.GetValue(2).GetType().GetField("Selected").GetValue(mainPads.GetValue(2)), "selected pad visual state");
                Capture(form,"soundboard.png");
                IDictionary grids=(IDictionary)Field(form,"buttonGrids");
                DataGridView grid=(DataGridView)grids["Main"];
                grid.Rows[2].Cells["mode"].Value="Стоп всё"; Pump();
                object binding=Bind(form,"Main",3);
                Check((string)binding.GetType().GetField("PlayMode").GetValue(binding)=="Стоп всё","table mode edit updates binding");
                Check((string)mainPads.GetValue(2).GetType().GetField("SoundName").GetValue(mainPads.GetValue(2))=="Остановить всё", "stop-all mode updates pad label");
                SetField(form,"learning",binding); SetField(form,"learnStart",DateTime.UtcNow);
                Call(form,"HandleLearn","Test MIDI","Note",2,64,1,true);
                Check(Field(form,"learning")==null && (int)binding.GetType().GetField("Number").GetValue(binding)==64 && (int)binding.GetType().GetField("Channel").GetValue(binding)==2,"MIDI Note learning accepts velocity 1");
                object faderBinding=Bind(form,"Fader",1);
                faderBinding.GetType().GetField("Source").SetValue(faderBinding,"CC");
                faderBinding.GetType().GetField("Port").SetValue(faderBinding,"Test MIDI");
                faderBinding.GetType().GetField("Channel").SetValue(faderBinding,1);
                faderBinding.GetType().GetField("Number").SetValue(faderBinding,11);
                object queue=Field(form,"incoming");
                Type eventType=asm.GetType("MVaveAudioDeck.MidiEvent",true);
                uint raw1=0xB0u | (11u << 8) | (10u << 16);
                uint raw2=0xB0u | (11u << 8) | (127u << 16);
                queue.GetType().GetMethod("Enqueue").Invoke(queue,new object[]{Activator.CreateInstance(eventType,new object[]{raw1,"Test MIDI"})});
                queue.GetType().GetMethod("Enqueue").Invoke(queue,new object[]{Activator.CreateInstance(eventType,new object[]{raw2,"Test MIDI"})});
                Call(form,"Tick",null,EventArgs.Empty);
                Check((int)faderBinding.GetType().GetField("CurrentPct").GetValue(faderBinding)==100,"MIDI fader burst applies latest value");
                string assignedTarget=Target(faderBinding);
                Call(form,"ResetMidiBind",faderBinding);
                Check((int)faderBinding.GetType().GetField("Number").GetValue(faderBinding)==-1 && Target(faderBinding)==assignedTarget,"resetting MIDI preserves assigned application");
                object knobBinding=Bind(form,"Knob",1);
                Call(form,"ChangeTarget",knobBinding,"custom.exe");
                ((ComboBox[])Field(form,"knobMode"))[0].SelectedIndex=0;
                Call(form,"ProcessKnob",knobBinding,1); Call(form,"ProcessKnob",knobBinding,1); Call(form,"ProcessKnob",knobBinding,65);
                Check(((int[])Field(form,"knobPendingSteps"))[0]==1,"relative encoder events batch with direction preserved");
                Call(form,"Tick",null,EventArgs.Empty);
                Check(((int[])Field(form,"knobPendingSteps"))[0]==0,"encoder batch flushes during tick");
                SetField(form,"learning",binding); SetField(form,"learnStart",DateTime.UtcNow.AddSeconds(-30));
                Call(form,"Tick",null,EventArgs.Empty);
                Check(Field(form,"learning")==null,"MIDI learn expires after timeout");
                tabs.SelectedIndex=2; Pump(); Check(((Array)pads["Track"]).Length==32,"thirty-two track pads");
                Capture(form,"track.png");
                tabs.SelectedIndex=0;form.Size=form.MinimumSize;Pump();
                Capture(form,"mixer-minimum.png");
                form.Close();
            }
            Console.WriteLine("ALL " + passed + " UI CHECKS PASSED"); return 0;
        }
        catch(Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }
}
