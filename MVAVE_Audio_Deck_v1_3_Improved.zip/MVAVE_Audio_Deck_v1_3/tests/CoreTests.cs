// Regression tests against the compiled application, with TEST-ONLY native substitutes.
// Build CoreNativeStub.c as a shared library outside the release directory.
// Map both winmm.dll (application assembly) and core_test_native (this test assembly)
// to that library with Mono .exe.config dllmap files. Never install the stub on Windows.
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

internal static class CoreTests
{
    [DllImport("core_test_native")] static extern void test_reset();
    [DllImport("core_test_native")] static extern void test_emit(int id, uint raw);
    [DllImport("core_test_native")] static extern void test_start_error(int enabled);
    [DllImport("core_test_native")] static extern void test_play_error(int enabled);
    [DllImport("core_test_native")] static extern void test_open_error(int enabled);
    [DllImport("core_test_native")] static extern void test_finish_all();
    [DllImport("core_test_native")] static extern int test_value(int key);
    static int passed;
    static object Invoke(object value, string method, params object[] args)
    { return value.GetType().GetMethod(method).Invoke(value, args); }
    static T Property<T>(object value, string name)
    { return (T)value.GetType().GetProperty(name).GetValue(value, null); }
    static void Check(bool valid, string message)
    {
        if (!valid) throw new Exception("FAIL: " + message);
        passed++; Console.WriteLine("PASS: " + message);
    }
    static void Fails<T>(Action action, string message) where T : Exception
    {
        try { action(); }
        catch (TargetInvocationException e) { Check(e.InnerException is T, message); return; }
        throw new Exception("FAIL: expected " + typeof(T).Name + ": " + message);
    }
    static int Main(string[] args)
    {
        string sound = Path.GetTempFileName();
        try
        {
            Assembly app = Assembly.LoadFrom(args.Length > 0 ? args[0] : "MVAVE_Audio_Deck.exe");
            Type midiType = app.GetType("MVaveAudioDeck.MidiPorts", true);
            Type eventType = app.GetType("MVaveAudioDeck.MidiEvent", true);
            Type soundType = app.GetType("MVaveAudioDeck.SoundBoard", true);
            Type queueType = typeof(System.Collections.Concurrent.ConcurrentQueue<>).MakeGenericType(eventType);
            object queue = Activator.CreateInstance(queueType);
            object midi = Activator.CreateInstance(midiType, new[] { queue });
            test_reset();
            Invoke(midi, "Open", new[] { 0, 1 }, new List<string> { "Controller A", "Controller B" });
            Check(Property<bool>(midi, "IsOpen") && Property<int>(midi, "OpenCount") == 2, "opens both selected MIDI inputs");
            IList opened = (IList)midiType.GetField("opened", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(midi);
            Delegate lateCallback = (Delegate)opened[0].GetType().GetField("Callback").GetValue(opened[0]);
            test_emit(0, 0xF8); test_emit(0, 0xFE); test_emit(0, 0x000140C0);
            Check(Property<int>(queue, "Count") == 0, "ignores timing clock, active sensing and program change");
            test_emit(0, 0x004007B0); test_emit(1, 0x007F3C90);
            test_emit(0, 0x00003C80); test_emit(1, 0x004000E0);
            Check(Property<int>(queue, "Count") == 4, "retains CC, Note On, Note Off and pitch bend");
            object[] events = ((IEnumerable)queue).CastObjects();
            Check((string)eventType.GetField("Device").GetValue(events[0]) == "Controller A" &&
                  (string)eventType.GetField("Device").GetValue(events[1]) == "Controller B", "events retain controller identity");
            Check((uint)eventType.GetField("Raw").GetValue(events[2]) == 0x00003C80, "note-off payload is preserved");
            for (int i = 0; i < 10000; i++) test_emit(0, (uint)(0x07B0 | ((i % 128) << 16)));
            Check(Property<int>(queue, "Count") == 4096, "MIDI burst cannot grow queue past configured capacity");
            Check((int)Invoke(midi, "TakeDroppedEventCount") == 5908, "overflow reports exact discarded-event count");
            Check((int)Invoke(midi, "TakeDroppedEventCount") == 0, "overflow counter resets after reading");
            events = ((IEnumerable)queue).CastObjects();
            Check((uint)eventType.GetField("Raw").GetValue(events[events.Length - 1]) == (uint)(0x07B0 | ((9999 % 128) << 16)), "overflow keeps newest controller position");
            System.Threading.Thread[] producers = new System.Threading.Thread[4];
            for (int i = 0; i < producers.Length; i++)
            {
                int device = i % 2;
                producers[i] = new System.Threading.Thread(delegate() { for(int n=0;n<3000;n++) test_emit(device, 0x004007B0); });
                producers[i].Start();
            }
            foreach(System.Threading.Thread producer in producers) producer.Join();
            Check(Property<int>(queue, "Count") >= 4096 && Property<int>(queue, "Count") <= 4100, "concurrent native callbacks keep queue bounded near capacity");
            Invoke(midi, "Close");
            Check(!Property<bool>(midi, "IsOpen") && test_value(1) == 2, "close releases both native inputs");
            Check(Property<int>(queue, "Count") == 0, "close drains stale events");
            lateCallback.DynamicInvoke(IntPtr.Zero, 0x3c3u, IntPtr.Zero, new IntPtr(0x004007B0), IntPtr.Zero);
            Check(Property<int>(queue, "Count") == 0, "late callback from closed endpoint cannot enqueue events");
            Check((int)Invoke(midi, "TakeDroppedEventCount") == 0, "close resets overflow diagnostics");
            Invoke(midi, "Close"); Check(test_value(1) == 2, "repeated close is harmless");
            test_start_error(1);
            Fails<IOException>(delegate { Invoke(midi, "Open", new[] { 0 }, new List<string> { "Controller A" }); }, "native start failure is reported");
            Check(!Property<bool>(midi, "IsOpen") && test_value(1) == 3, "start failure closes its native handle");
            test_start_error(0);
            Invoke(midi, "Open", new[] { 0 }, new List<string> { "Controller A" });
            ((IDisposable)midi).Dispose(); Check(test_value(1) == 4, "dispose releases reopened MIDI input");

            test_reset();
            object board = Activator.CreateInstance(soundType);
            Check(!(bool)Invoke(board, "IsPlaying", 1), "unassigned playback is inactive");
            Invoke(board, "Play", 1, sound, false);
            Check((bool)Invoke(board, "IsPlaying", 1) && Property<int>(board, "ActiveCount") == 1, "play registers active MCI alias");
            Invoke(board, "Play", 1, sound, false);
            Check(test_value(2) == 2 && test_value(3) == 1 && Property<int>(board, "ActiveCount") == 1, "retrigger closes previous alias before reopening");
            Invoke(board, "Play", 1, sound, true);
            Check(Property<int>(board, "ActiveCount") == 0 && test_value(2) == 2 && test_value(3) == 2, "toggle stops without reopening a playing sound");
            Invoke(board, "Play", 1, sound, false); Invoke(board, "Play", 2, sound, false);
            test_finish_all(); Invoke(board, "ReapFinished");
            Check(Property<int>(board, "ActiveCount") == 0 && test_value(2) == test_value(3), "completion sweep closes every finished alias");
            Invoke(board, "Play", 3, sound, false); test_finish_all();
            Check(!(bool)Invoke(board, "IsPlaying", 3) && test_value(2) == test_value(3), "IsPlaying also cleans up completed files");
            test_play_error(1);
            Fails<IOException>(delegate { Invoke(board, "Play", 4, sound, false); }, "MCI play failure is reported");
            Check(Property<int>(board, "ActiveCount") == 0 && test_value(2) == test_value(3), "failed play closes the newly opened alias");
            test_play_error(0); test_open_error(1);
            Fails<IOException>(delegate { Invoke(board, "Play", 4, sound, false); }, "MCI open failure is reported");
            Check(Property<int>(board, "ActiveCount") == 0, "failed open leaves no active entry");
            test_open_error(0);
            Fails<IOException>(delegate { Invoke(board, "Play", 4, sound + "-missing", false); }, "missing sound is rejected before native playback");
            Invoke(board, "Play", 1, sound, false); Invoke(board, "Play", 2, sound, false);
            ((IDisposable)board).Dispose();
            Check(Property<int>(board, "ActiveCount") == 0 && test_value(2) == test_value(3), "dispose closes all remaining sounds");
            ((IDisposable)board).Dispose(); Check(test_value(2) == test_value(3), "repeated sound disposal is harmless");
            Console.WriteLine("Core regression tests: " + passed + " passed."); return 0;
        }
        catch(Exception error) { Console.Error.WriteLine(error); return 1; }
        finally { File.Delete(sound); }
    }
    static object[] CastObjects(this IEnumerable values)
    {
        List<object> list = new List<object>(); foreach(object value in values) list.Add(value); return list.ToArray();
    }
}
