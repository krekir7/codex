/* Test-only winmm stand-in. Build outside the application directory; never ship as winmm.dll. */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef void (*midi_callback)(void *, uint32_t, void *, void *, void *);
static midi_callback callbacks[8];
static int midi_open, midi_closed, start_error;
static int mci_open, mci_closed, mci_playing, fail_play, fail_open;
static unsigned char modes[512], opened[512];

void test_reset(void) {
    memset(callbacks, 0, sizeof(callbacks));
    memset(modes, 0, sizeof(modes)); memset(opened, 0, sizeof(opened));
    midi_open = midi_closed = start_error = 0;
    mci_open = mci_closed = mci_playing = fail_play = fail_open = 0;
}
void test_emit(int id, uint32_t raw) {
    if(id >= 0 && id < 8 && callbacks[id])
        callbacks[id]((void *)(intptr_t)(id + 1), 0x3c3, 0, (void *)(uintptr_t)raw, 0);
}
void test_start_error(int enabled) { start_error = enabled; }
void test_play_error(int enabled) { fail_play = enabled; }
void test_open_error(int enabled) { fail_open = enabled; }
void test_finish_all(void) { memset(modes, 0, sizeof(modes)); mci_playing = 0; }
int test_value(int key) {
    switch(key) {
        case 0: return midi_open; case 1: return midi_closed;
        case 2: return mci_open; case 3: return mci_closed; case 4: return mci_playing;
    } return -1;
}
uint32_t midiInOpen(void **handle, uint32_t id, midi_callback callback, void *instance, uint32_t flags) {
    if(id >= 8) return 2;
    callbacks[id] = callback; *handle = (void *)(intptr_t)(id + 1); midi_open++; return 0;
}
uint32_t midiInStart(void *handle) { return start_error ? 1 : 0; }
uint32_t midiInStop(void *handle) { return 0; }
uint32_t midiInReset(void *handle) { return 0; }
uint32_t midiInClose(void *handle) {
    callbacks[(intptr_t)handle - 1] = 0; midi_closed++; return 0;
}
uint32_t midiInGetNumDevs(void) { return 0; }

static void utf16_to_ascii(const uint16_t *source, char *destination, int capacity) {
    int i; for(i=0; source[i] && i<capacity-1; i++) destination[i] = (char)source[i];
    destination[i] = 0;
}
static void ascii_to_utf16(const char *source, uint16_t *destination, int capacity) {
    if(!destination || capacity < 1) return;
    int i; for(i=0; source[i] && i<capacity-1; i++) destination[i] = (uint16_t)source[i];
    destination[i] = 0;
}
uint32_t mciSendStringW(const uint16_t *command, uint16_t *result, uint32_t length, void *window) {
    char text[2048]; utf16_to_ascii(command, text, sizeof(text));
    char *alias = strstr(text, "deck");
    int index = alias ? atoi(alias + 4) % 512 : -1;
    if(strncmp(text, "open ", 5) == 0) {
        if(fail_open) return 42;
        if(index < 0) return 43;
        opened[index] = 1; modes[index] = 0; mci_open++; return 0;
    }
    if(index < 0 || !opened[index]) return 44;
    if(strncmp(text, "play ", 5) == 0) {
        if(fail_play) return 45;
        modes[index] = 1; mci_playing++; return 0;
    }
    if(strncmp(text, "status ", 7) == 0) {
        ascii_to_utf16(modes[index] ? "playing" : "stopped", result, length); return 0;
    }
    if(strncmp(text, "stop ", 5) == 0) {
        if(modes[index]) mci_playing--;
        modes[index] = 0; return 0;
    }
    if(strncmp(text, "close ", 6) == 0) {
        opened[index] = 0; if(modes[index]) mci_playing--;
        modes[index] = 0; mci_closed++; return 0;
    }
    return 46;
}
int mciGetErrorStringW(uint32_t code, uint16_t *description, uint32_t length) {
    ascii_to_utf16("Simulated MCI failure", description, length); return 1;
}
