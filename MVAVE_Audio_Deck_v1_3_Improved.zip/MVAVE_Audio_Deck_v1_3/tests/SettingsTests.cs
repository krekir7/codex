// Standalone regression tests. No form construction or Windows audio/MIDI is required.
// Compile: mcs -r:System.Windows.Forms -r:System.Drawing -out:SettingsTests.exe SettingsTests.cs
// Run: mono SettingsTests.exe ../MVAVE_Audio_Deck.exe
using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Xml;

internal static class SettingsTests
{
    static Type formType, bindingType;
    static int passed;
    static string directory;
    const BindingFlags Fields = BindingFlags.Instance | BindingFlags.NonPublic;
    const BindingFlags Methods = BindingFlags.Instance | BindingFlags.NonPublic;
    static object Get(object form, string name) { return formType.GetField(name, Fields).GetValue(form); }
    static void Set(object form, string name, object value) { formType.GetField(name, Fields).SetValue(form, value); }
    static object Call(object form, string name) { return formType.GetMethod(name, Methods).Invoke(form, null); }
    static void Check(bool condition, string name)
    {
        if (!condition) throw new Exception("FAIL: " + name);
        passed++; Console.WriteLine("PASS: " + name);
    }
    static object NewForm(string name)
    {
        object form = FormatterServices.GetUninitializedObject(formType);
        IList bindings = (IList)Activator.CreateInstance(typeof(System.Collections.Generic.List<>).MakeGenericType(bindingType));
        foreach (string kind in new[] { "Fader", "Knob", "Main", "Track" })
        {
            int count = kind == "Main" ? 11 : kind == "Track" ? 32 : 8;
            for (int i = 1; i <= count; i++) bindings.Add(Activator.CreateInstance(bindingType, new object[] { kind, i }));
        }
        Set(form, "bindings", bindings);
        Set(form, "savedEncoderModes", new int[8]);
        Set(form, "knobMode", new ComboBox[8]);
        Set(form, "configPath", Path.Combine(directory, name + ".xml"));
        Set(form, "settingsWarning", "");
        return form;
    }
    static object Binding(object form, string kind, int index)
    {
        foreach (object binding in (IList)Get(form, "bindings"))
            if ((string)bindingType.GetField("Kind").GetValue(binding) == kind && (int)bindingType.GetField("Index").GetValue(binding) == index) return binding;
        throw new Exception("Binding absent");
    }
    static object BGet(object form, string kind, int index, string field) { return bindingType.GetField(field).GetValue(Binding(form, kind, index)); }
    static void BSet(object form, string kind, int index, string field, object value) { bindingType.GetField(field).SetValue(Binding(form, kind, index), value); }
    static string PathFor(object form) { return (string)Get(form, "configPath"); }
    static int Main(string[] args)
    {
        try
        {
            Assembly app = Assembly.LoadFrom(args.Length == 0 ? "MVAVE_Audio_Deck.exe" : args[0]);
            formType = app.GetType("MVaveAudioDeck.DeckForm", true);
            bindingType = app.GetType("MVaveAudioDeck.Binding", true);
            directory = Path.Combine(Path.GetTempPath(), "audio-deck-settings-test-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);

            object legacy = NewForm("legacy");
            File.WriteAllText(PathFor(legacy), "<audioDeck version='1.2'><encoderMode index='2' value='1'/><binding kind='Fader' index='1' source='CC' channel='1' number='7' port='SMC-Mixer' target='browser.exe' file='Demo_Sounds/Chime.wav' play='Играть'/></audioDeck>");
            Call(legacy, "LoadSettings");
            Check((int)BGet(legacy, "Fader", 1, "Number") == 7 && (string)BGet(legacy, "Fader", 1, "Target") == "browser.exe", "legacy v1.2 MIDI and app assignments load");
            Check(((int[])Get(legacy, "savedEncoderModes"))[1] == 1, "encoder mode round trip input");
            Check(Path.IsPathRooted((string)BGet(legacy, "Fader", 1, "FileName")), "relative sound resolves to an absolute runtime path");
            Check((bool)Call(legacy, "SaveSettings"), "atomic save succeeds");
            XmlDocument saved = new XmlDocument(); saved.Load(PathFor(legacy));
            Check(!Path.IsPathRooted(saved.SelectSingleNode("/audioDeck/binding[@kind='Fader'][@index='1']").Attributes["file"].Value), "bundled sounds saved as portable relative paths");
            BSet(legacy, "Fader", 1, "Target", "discord.exe");
            Check((bool)Call(legacy, "SaveSettings"), "second atomic save succeeds");
            XmlDocument backup = new XmlDocument(); backup.Load(PathFor(legacy) + ".bak");
            Check(backup.SelectSingleNode("/audioDeck/binding[@kind='Fader'][@index='1']").Attributes["target"].Value == "browser.exe", "backup retains previous successful save");
            object fresh = NewForm("legacy"); Call(fresh, "LoadSettings");
            Check((string)BGet(fresh, "Fader", 1, "Target") == "discord.exe", "new instance loads latest assignments");

            object invalid = NewForm("invalid");
            File.WriteAllText(PathFor(invalid), "<audioDeck><encoderMode index='1' value='99'/><binding/><binding kind='Main' index='1' source='PB' channel='1' number='0' play='unknown'/><binding kind='Knob' index='2' source='CC' channel='0' number='200'/></audioDeck>");
            Call(invalid, "LoadSettings");
            Check((int)BGet(invalid, "Main", 1, "Number") == -1 && (int)BGet(invalid, "Knob", 2, "Number") == -1, "invalid MIDI ranges and kinds reset safely");
            Check((string)BGet(invalid, "Main", 1, "PlayMode") == "Играть" && ((int[])Get(invalid, "savedEncoderModes"))[0] == 0, "invalid playback and encoder modes default safely");
            Check(((string)Get(invalid, "settingsWarning")).Length > 0, "malformed records produce a startup warning");

            File.WriteAllText(PathFor(legacy), "<broken");
            object recovered = NewForm("legacy"); Call(recovered, "LoadSettings");
            Check((bool)Get(recovered, "settingsRecoveredFromBackup") && (string)BGet(recovered, "Fader", 1, "Target") == "browser.exe", "corrupt main recovers previous valid backup");
            Check((bool)Call(recovered, "SaveSettings"), "save after recovery succeeds");
            Check(Directory.GetFiles(directory, "legacy.xml.corrupt-*").Length == 1 && File.ReadAllText(Directory.GetFiles(directory, "legacy.xml.corrupt-*")[0]) == "<broken", "damaged original preserved separately");
            backup.Load(PathFor(legacy) + ".bak");
            Check(backup.SelectSingleNode("/audioDeck/binding[@kind='Fader'][@index='1']").Attributes["target"].Value == "browser.exe", "recovery save preserves valid backup");

            object broken = NewForm("broken");
            File.WriteAllText(PathFor(broken), "<broken"); Call(broken, "LoadSettings");
            Check((bool)Get(broken, "settingsSaveBlocked") && !(bool)Call(broken, "SaveSettings"), "unrecoverable settings block automatic overwrites");
            Check(File.ReadAllText(PathFor(broken)) == "<broken", "unrecoverable original remains intact");

            object entity = NewForm("entity");
            File.WriteAllText(PathFor(entity), "<!DOCTYPE audioDeck [<!ENTITY value 'external'>]><audioDeck><binding kind='Main' index='1' file='&value;'/></audioDeck>");
            Call(entity, "LoadSettings");
            Check((bool)Get(entity, "settingsSaveBlocked"), "DTD documents rejected");
            Check(Directory.GetFiles(directory, "*.tmp").Length == 0, "no temporary save files left behind");
            Console.WriteLine("Settings regression tests: " + passed + " passed.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
        finally { if (directory != null && Directory.Exists(directory)) Directory.Delete(directory, true); }
    }
}
