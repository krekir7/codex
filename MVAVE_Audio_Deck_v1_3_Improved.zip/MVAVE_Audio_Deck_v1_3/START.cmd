@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" > "%~dp0BUILD_LOG.txt" 2>&1
if errorlevel 1 (
  echo BUILD FAILED. See BUILD_LOG.txt
  type "%~dp0BUILD_LOG.txt"
  pause
  exit /b 1
)
start "" "%~dp0MVAVE_Audio_Deck.exe"
exit /b 0
