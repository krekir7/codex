﻿param([switch]$Force)
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $dir 'MVAVE_Audio_Deck.exe'
$temporaryExe = $null
try {
    $sources = @(
        (Join-Path $dir 'MVaveAudioDeck.cs'),
        (Join-Path $dir 'DeckControls.cs')
    )
    foreach ($source in $sources) {
        if (-not (Test-Path -LiteralPath $source)) { throw ('Missing source: ' + $source) }
    }
    $icon = Join-Path $dir 'audio_deck.ico'
    $manifest = Join-Path $dir 'app.manifest'
    $inputs = @($sources) + @($MyInvocation.MyCommand.Path)
    if (Test-Path -LiteralPath $icon) { $inputs += $icon }
    if (Test-Path -LiteralPath $manifest) { $inputs += $manifest }
    $needsBuild = $Force -or -not (Test-Path -LiteralPath $exe)
    if (-not $needsBuild) {
        $exeTime = (Get-Item -LiteralPath $exe).LastWriteTimeUtc
        foreach ($inputFile in $inputs) {
            if ((Get-Item -LiteralPath $inputFile).LastWriteTimeUtc -gt $exeTime) { $needsBuild = $true; break }
        }
    }
    if (-not $needsBuild) { Write-Output 'BUILD UP TO DATE'; exit 0 }

    $paths = @(
        (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'),
        (Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe')
    )
    $compiler = $paths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (-not $compiler) { throw '.NET Framework 4.x C# compiler not found. Enable/install .NET Framework 4.8.' }
    Write-Output ('Compiler: ' + $compiler)
    $temporaryExe = Join-Path $dir ('.audio-deck-build-' + [Guid]::NewGuid().ToString('N') + '.exe')
    $arguments = @(
        '/nologo', '/target:winexe', '/platform:anycpu', '/langversion:5',
        '/optimize+', '/utf8output', ('/out:' + $temporaryExe),
        '/reference:System.dll', '/reference:System.Core.dll',
        '/reference:System.Drawing.dll', '/reference:System.Windows.Forms.dll',
        '/reference:System.Xml.dll'
    )
    if (Test-Path -LiteralPath $icon) { $arguments += ('/win32icon:' + $icon) }
    if (Test-Path -LiteralPath $manifest) { $arguments += ('/win32manifest:' + $manifest) }
    $arguments += $sources
    & $compiler @arguments
    if ($LASTEXITCODE -ne 0) { throw ('Compiler exit code ' + $LASTEXITCODE) }
    if (-not (Test-Path -LiteralPath $temporaryExe)) { throw 'Compiler did not create the executable' }
    Move-Item -LiteralPath $temporaryExe -Destination $exe -Force
    $temporaryExe = $null
    Write-Output 'BUILD OK: MVAVE_Audio_Deck.exe'
    exit 0
} catch {
    Write-Output ('BUILD FAILED: ' + $_.Exception.Message)
    Write-Output 'The previous executable was preserved. Close Audio Deck before rebuilding.'
    exit 1
} finally {
    if ($temporaryExe -and (Test-Path -LiteralPath $temporaryExe)) {
        Remove-Item -LiteralPath $temporaryExe -Force -ErrorAction SilentlyContinue
    }
}
