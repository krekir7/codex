@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0MVAVE_Audio_Deck.exe" --audio-diagnostics
