// Compile together with the production sources, selecting /main:MVaveAudioDeck.AudioTests.
// Fakes implement the actual imported interfaces: discovery/read/write use the production traversal.
// This tests HRESULT and routing logic, not real Windows COM marshalling or audio hardware.
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace MVaveAudioDeck
{
    internal static class AudioTests
    {
        const int Denied = unchecked((int)0x80070005);
        const int CrossProcessSuccess = 0x0889000D; // AUDCLNT_S_NO_SINGLE_PROCESS
        static int passed;
        static void Check(bool value, string message)
        {
            if (!value) throw new Exception("FAIL: " + message);
            passed++; Console.WriteLine("PASS: " + message);
        }
        static void Fails(Action action, string text, string message)
        {
            try { action(); }
            catch (Exception error) { Check(error.Message.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0, message); return; }
            throw new Exception("FAIL: missing exception: " + message);
        }
        static int Main()
        {
            Func<WindowsAudio.IMMDeviceEnumerator> oldFactory = WindowsAudio.EnumeratorFactory;
            Func<uint, string> oldNames = WindowsAudio.ProcessNameResolver;
            try
            {
                FakeSession music = new FakeSession(10, 0.25f) { ProcessResult = CrossProcessSuccess };
                FakeSession discord1 = new FakeSession(20, 0.50f);
                FakeSession discord2 = new FakeSession(20, 0.30f) { ProcessResult = 1 };
                FakeSession paused = new FakeSession(30, 0.40f) { State = 0 };
                FakeSession expired = new FakeSession(40, 0.40f) { State = 2 };
                FakeSession system = new FakeSession(0, 0.90f);
                FakeEndpoint first = new FakeEndpoint(discord1, expired, system);
                FakeEndpoint second = new FakeEndpoint(music, discord2, paused);
                FakeEnumerator devices = new FakeEnumerator(first, second);
                WindowsAudio.EnumeratorFactory = delegate { return devices; };
                WindowsAudio.ProcessNameResolver = delegate(uint pid)
                {
                    if (pid == 10) return "Яндекс Музыка";
                    if (pid == 20) return "DISCORD.EXE";
                    if (pid == 30) return "C:\\Apps\\Paused Player.EXE";
                    if (pid == 40) throw new Exception("Expired process should never be looked up");
                    throw new Exception("Unknown PID " + pid);
                };
                List<string> list = WindowsAudio.ListApps();
                Check(devices.LastFlow == 0 && devices.LastMask == 1 && devices.EnumCalls == 1 && devices.DefaultCalls == 0, "app discovery enumerates every active render endpoint without using the default");
                Check(list.Count == 4 && list[0] == WindowsAudio.MasterTarget, "app list deduplicates processes while preserving master target");
                Check(list.Contains("яндекс музыка.exe"), "cross-process success HRESULT discovers Unicode Electron process on second output");
                Check(list.Contains("discord.exe"), "S_FALSE GetProcessId remains successful");
                Check(list.Contains("paused player.exe"), "inactive sessions remain available and full paths normalize");
                Check(WindowsAudio.LastWarning == "", "expired and system sessions are ignored without false errors");
                Check(WindowsAudio.GetVolume("  ЯНДЕКС МУЗЫКА.EXE  ") == 25, "read discovers the same Unicode target on nondefault output");
                Check(WindowsAudio.SetVolume("\"C:\\Program Files\\Music\\Яндекс Музыка.exe\"", 73) == 1 && Near(music.Volume, .73f), "write accepts quoted full path and controls nondefault output");
                Check(WindowsAudio.SetVolume("discord", 61) == 2 && Near(discord1.Volume, .61f) && Near(discord2.Volume, .61f), "write updates every matching app session across outputs");
                Check(WindowsAudio.SetVolume("paused player", 42) == 1 && Near(paused.Volume, .42f), "paused app session volume can be changed");
                discord1.SetResult = 1;
                Check(WindowsAudio.SetVolume("discord.exe", 101) == 2 && Near(discord1.Volume, 1f) && Near(discord2.Volume, 1f), "positive set HRESULT succeeds and percentage clamps to 100");
                WindowsAudio.SetVolume("Яндекс Музыка", -3);
                Check(Near(music.Volume, 0f), "negative volume clamps to zero");
                Check(WindowsAudio.GetVolume("missing.exe") == null && WindowsAudio.SetVolume("missing", 50) == 0, "missing app is distinct from native failure");
                Check(WindowsAudio.GetVolume("") == null && WindowsAudio.SetVolume(" ", 50) == 0, "empty assignment performs no write");
                Check(WindowsAudio.NormalizeProcessName("\"C:/Apps/Яндекс Музыка.EXE\"") == "яндекс музыка.exe", "normalization preserves Unicode and accepts either path separator");
                Check(WindowsAudio.NormalizeProcessName("  ") == "" && WindowsAudio.NormalizeProcessName("C:\\") == "", "empty and directory-only names are rejected");

                int enumerations = devices.EnumCalls;
                Check(WindowsAudio.SetVolume(WindowsAudio.MasterTarget, 44) == 1 && Near(first.Master.Volume, .44f) && Near(second.Master.Volume, .80f), "master write changes only the default output");
                Check(WindowsAudio.GetVolume(WindowsAudio.MasterTarget) == 44 && devices.DefaultCalls == 2 && devices.EnumCalls == enumerations, "master read uses default endpoint without per-app enumeration");

                first.ActivateResult = Denied;
                Check(WindowsAudio.ListApps().Contains("яндекс музыка.exe") && WindowsAudio.LastWarning.Contains("80070005"), "one inaccessible endpoint preserves discovery from other outputs and reports HRESULT");
                Check(WindowsAudio.SetVolume("Яндекс Музыка", 55) == 1 && Near(music.Volume, .55f) && WindowsAudio.LastWarning.Length > 0, "one failed output does not prevent successful writes elsewhere");
                Check(WindowsAudio.GetVolume("Яндекс Музыка") == 55, "one failed output does not prevent successful reads elsewhere");
                first.ActivateResult = 0;
                discord1.SetResult = Denied; discord2.SetResult = 0;
                Check(WindowsAudio.SetVolume("discord", 66) == 1 && Near(discord2.Volume, .66f) && WindowsAudio.LastWarning.Contains("SetMasterVolume"), "one failed session preserves remaining successful app writes");
                discord2.SetResult = Denied;
                Fails(delegate { WindowsAudio.SetVolume("discord", 22); }, "80070005", "all matching write failures report HRESULT instead of no-session");
                discord1.SetResult = discord2.SetResult = 0;
                discord1.GetResult = Denied;
                Check(WindowsAudio.GetVolume("discord") == 66 && WindowsAudio.LastWarning.Contains("GetMasterVolume"), "failed first session read falls through to a working session on another output");
                discord2.GetResult = Denied;
                Fails(delegate { WindowsAudio.GetVolume("discord"); }, "80070005", "all matching read failures are diagnosed");
                discord1.GetResult = discord2.GetResult = 0;
                music.ProcessResult = Denied;
                Check(!WindowsAudio.ListApps().Contains("яндекс музыка.exe") && WindowsAudio.LastWarning.Contains("GetProcessId"), "negative process HRESULT is reported and session is excluded");
                music.ProcessResult = CrossProcessSuccess;
                first.ActivateResult = second.ActivateResult = Denied;
                Fails(delegate { WindowsAudio.ListApps(); }, "80070005", "failure of every endpoint prevents a misleading empty app list");
                first.ActivateResult = second.ActivateResult = 0;
                devices.EnumResult = Denied;
                Fails(delegate { WindowsAudio.ListApps(); }, "EnumAudioEndpoints", "top-level native enumeration error includes failing operation");
                string failedReport = WindowsAudio.Diagnose();
                Check(failedReport.Contains("80070005") && !failedReport.Contains("Ошибок перечисления не обнаружено"), "diagnostic report cannot label a failed enumeration healthy");
                devices.EnumResult = 0;
                string report = WindowsAudio.Diagnose();
                Check(report.Contains("яндекс музыка.exe") && report.Contains("PID 10") && report.Contains("0889000D") && report.Contains("Активных устройств воспроизведения: 2"), "diagnostics include actual endpoint/session identity and positive native status");
                Check(typeof(WindowsAudio.IAudioSessionEnumerator).GetMethod("GetSession").GetParameters()[1].ParameterType == typeof(WindowsAudio.IAudioSessionControl).MakeByRefType(), "GetSession declaration matches native base-interface return type");
                Check(typeof(WindowsAudio.IMMDeviceCollection).GUID == new Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), "device collection GUID matches Windows SDK");
                Check(typeof(WindowsAudio.IAudioSessionControl).GUID == new Guid("F4B1A599-7266-4319-A8CA-E70ACB11E8CD"), "base session control GUID matches Windows SDK");
                Console.WriteLine("Audio regression tests: " + passed + " passed."); return 0;
            }
            catch(Exception error) { Console.Error.WriteLine(error); return 1; }
            finally { WindowsAudio.EnumeratorFactory = oldFactory; WindowsAudio.ProcessNameResolver = oldNames; }
        }
        static bool Near(float left, float right) { return Math.Abs(left - right) < .0001f; }
        sealed class FakeEnumerator : WindowsAudio.IMMDeviceEnumerator
        {
            internal int EnumCalls, DefaultCalls, LastFlow, EnumResult;
            internal uint LastMask;
            readonly FakeCollection devices;
            internal FakeEnumerator(params FakeEndpoint[] endpoints) { devices = new FakeCollection(endpoints); }
            public int EnumAudioEndpoints(int flow, uint mask, out WindowsAudio.IMMDeviceCollection value) { EnumCalls++; LastFlow=flow; LastMask=mask; value=devices; return EnumResult; }
            public int GetDefaultAudioEndpoint(int flow, int role, out WindowsAudio.IMMDevice value) { DefaultCalls++; value=devices.Endpoints[0]; return 0; }
            public int GetDevice(string id, out WindowsAudio.IMMDevice value) { value=null; return Denied; }
            public int RegisterEndpointNotificationCallback(IntPtr p) { return 0; }
            public int UnregisterEndpointNotificationCallback(IntPtr p) { return 0; }
        }
        sealed class FakeCollection : WindowsAudio.IMMDeviceCollection
        {
            internal readonly FakeEndpoint[] Endpoints;
            internal FakeCollection(FakeEndpoint[] endpoints) { Endpoints=endpoints; }
            public int GetCount(out uint value) { value=(uint)Endpoints.Length; return 0; }
            public int Item(uint index, out WindowsAudio.IMMDevice value) { value=Endpoints[index]; return 0; }
        }
        sealed class FakeEndpoint : WindowsAudio.IMMDevice
        {
            internal readonly FakeMaster Master = new FakeMaster();
            readonly FakeManager manager;
            internal int ActivateResult;
            internal FakeEndpoint(params FakeSession[] sessions) { manager=new FakeManager(sessions); }
            public int Activate(ref Guid iid, uint context, IntPtr p, out object value)
            {
                value=null; if(ActivateResult < 0) return ActivateResult;
                if(iid==typeof(WindowsAudio.IAudioSessionManager2).GUID) value=manager;
                if(iid==typeof(WindowsAudio.IAudioEndpointVolume).GUID) value=Master;
                return value==null ? Denied : 0;
            }
        }
        sealed class FakeManager : WindowsAudio.IAudioSessionManager2
        {
            readonly FakeSessions sessions;
            internal FakeManager(FakeSession[] values) { sessions=new FakeSessions(values); }
            public int GetAudioSessionControl(IntPtr id, uint flags, out WindowsAudio.IAudioSessionControl value) { value=null; return Denied; }
            public int GetSimpleAudioVolume(IntPtr id, uint flags, out WindowsAudio.ISimpleAudioVolume value) { value=null; return Denied; }
            public int GetSessionEnumerator(out WindowsAudio.IAudioSessionEnumerator value) { value=sessions; return 0; }
        }
        sealed class FakeSessions : WindowsAudio.IAudioSessionEnumerator
        {
            readonly FakeSession[] sessions;
            internal FakeSessions(FakeSession[] values) { sessions=values; }
            public int GetCount(out int value) { value=sessions.Length; return 0; }
            public int GetSession(int index, out WindowsAudio.IAudioSessionControl value) { value=sessions[index]; return 0; }
        }
        sealed class FakeSession : WindowsAudio.IAudioSessionControl, WindowsAudio.IAudioSessionControl2, WindowsAudio.ISimpleAudioVolume
        {
            readonly uint pid;
            internal float Volume;
            internal int State=1, ProcessResult, SetResult, GetResult;
            internal FakeSession(uint process, float volume) { pid=process; Volume=volume; }
            public int GetState(out int value) { value=State; return 0; }
            public int GetDisplayName(out string value) { value=""; return 0; }
            public int SetDisplayName(string value, IntPtr context) { return 0; }
            public int GetIconPath(out string value) { value=""; return 0; }
            public int SetIconPath(string value, IntPtr context) { return 0; }
            public int GetGroupingParam(out Guid value) { value=Guid.Empty; return 0; }
            public int SetGroupingParam(ref Guid value, IntPtr context) { return 0; }
            public int RegisterAudioSessionNotification(IntPtr p) { return 0; }
            public int UnregisterAudioSessionNotification(IntPtr p) { return 0; }
            public int GetSessionIdentifier(out string value) { value="fake"; return 0; }
            public int GetSessionInstanceIdentifier(out string value) { value="fake"; return 0; }
            public int GetProcessId(out uint value) { value=pid; return ProcessResult; }
            public int IsSystemSoundsSession() { return pid==0 ? 0 : 1; }
            public int SetDuckingPreference(bool value) { return 0; }
            public int SetMasterVolume(float value, ref Guid context) { if(SetResult>=0) Volume=value; return SetResult; }
            public int GetMasterVolume(out float value) { value=Volume; return GetResult; }
            public int SetMute(bool value, ref Guid context) { return 0; }
            public int GetMute(out bool value) { value=false; return 0; }
        }
        sealed class FakeMaster : WindowsAudio.IAudioEndpointVolume
        {
            internal float Volume=.80f;
            public int RegisterControlChangeNotify(IntPtr p) { return 0; }
            public int UnregisterControlChangeNotify(IntPtr p) { return 0; }
            public int GetChannelCount(out uint count) { count=2; return 0; }
            public int SetMasterVolumeLevel(float value, IntPtr context) { return 0; }
            public int SetMasterVolumeLevelScalar(float value, ref Guid context) { Volume=value; return 0; }
            public int GetMasterVolumeLevel(out float value) { value=0; return 0; }
            public int GetMasterVolumeLevelScalar(out float value) { value=Volume; return 0; }
        }
    }
}
