// Form integration tests: real UI events, MIDI queue and Tick; only the audio API is replaced.
// Build as a separate executable referencing System.Windows.Forms and System.Drawing.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Threading;
using System.Reflection;
using System.Windows.Forms;

internal static class VolumeIntegrationTests
{
    private const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    private static Assembly assembly;
    private static int passed;
    private static void Check(bool ok,string message) { if(!ok)throw new Exception(message);Console.WriteLine("PASS "+message);passed++; }
    private static object Get(object obj,string field) { return obj.GetType().GetField(field,Private).GetValue(obj); }
    private static void Set(object obj,string field,object value) { obj.GetType().GetField(field,Private).SetValue(obj,value); }
    private static object Call(object obj,string method,params object[] args) { return obj.GetType().GetMethod(method,Private).Invoke(obj,args); }
    private static object BGet(object binding,string field) { return binding.GetType().GetField(field).GetValue(binding); }
    private static void BSet(object binding,string field,object value) { binding.GetType().GetField(field).SetValue(binding,value); }
    private sealed class Fixture : IDisposable
    {
        internal Form Form;
        internal object Fader,Knob;
        internal int Actual=50,Reads,Failures,ReadFailures;
        internal bool ThrowFailure;
        internal readonly List<int> Writes = new List<int>();
        internal readonly List<string> Targets = new List<string>();
        internal Fixture()
        {
            Form=(Form)Activator.CreateInstance(assembly.GetType("MVaveAudioDeck.DeckForm",true),new object[]{true});
            Form.StartPosition=FormStartPosition.Manual;Form.Location=new Point(10,10);Form.Show();Application.DoEvents();
            Fader=Call(Form,"B","Fader",1);Knob=Call(Form,"B","Knob",1);
            Call(Form,"ChangeTarget",Fader,"test-app.exe");Call(Form,"ChangeTarget",Knob,"test-app.exe");
            Set(Form,"volumeWriter",new Func<string,int,int>(Write));
            Set(Form,"volumeReader",new Func<string,int?>(Read));
        }
        private int Write(string target,int pct)
        {
            Targets.Add(target);Writes.Add(pct);
            if(Failures>0) {Failures--;if(ThrowFailure)throw new InvalidOperationException("Transient backend error");return 0;}
            Actual=pct;return 1;
        }
        private int? Read(string target) { Reads++;if(ReadFailures>0){ReadFailures--;return null;}return Actual; }
        internal void Tick() { Call(Form,"Tick",null,EventArgs.Empty); }
        internal void Ready(object binding) { BSet(binding,"LastApplied",DateTime.UtcNow.AddSeconds(-5)); }
        internal void MouseKey(Keys key)
        {
            object control=((Array)Get(Form,"faderLevel")).GetValue(0);
            Call(control,"OnKeyDown",new KeyEventArgs(key));
        }
        internal void Pending(int pct) { Call(Form,"SetStripVolume",Fader,pct); }
        internal void Midi(int value)
        {
            BSet(Fader,"Source","CC");BSet(Fader,"Port","Test MIDI");BSet(Fader,"Channel",1);BSet(Fader,"Number",11);
            uint raw=0xB0u|(11u<<8)|((uint)value<<16);
            object ev=Activator.CreateInstance(assembly.GetType("MVaveAudioDeck.MidiEvent",true),new object[]{raw,"Test MIDI"});
            object queue=Get(Form,"incoming");queue.GetType().GetMethod("Enqueue").Invoke(queue,new object[]{ev});
        }
        public void Dispose() { Form.Close();Form.Dispose(); }
    }
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            if(args.Length!=1)throw new ArgumentException("Usage: VolumeIntegrationTests.exe <AudioDeck.exe>");
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
            assembly=Assembly.LoadFrom(System.IO.Path.GetFullPath(args[0]));
            using(Fixture f=new Fixture())
            {
                f.MouseKey(Keys.End);
                Check(f.Writes.Count==0,"fader UI event queues work instead of writing synchronously");
                f.Tick();
                Check(f.Writes.Count==1&&f.Writes[0]==100&&f.Actual==100&&f.Targets[0]=="test-app.exe","real fader event and Tick reach backend");
            }
            using(Fixture f=new Fixture())
            {
                object control=((Array)Get(f.Form,"faderLevel")).GetValue(0);
                Call(control,"OnMouseDown",new MouseEventArgs(MouseButtons.Left,1,20,18,0));
                Call(control,"OnMouseUp",new MouseEventArgs(MouseButtons.Left,1,20,18,0));
                f.Tick();Check(f.Writes.Count==1&&f.Actual==100,"mouse fader drag reaches audio backend");
            }
            using(Fixture f=new Fixture())
            {
                f.Pending(35);
                System.Windows.Forms.Timer timer=(System.Windows.Forms.Timer)Get(f.Form,"timer");timer.Start();
                Stopwatch watch=Stopwatch.StartNew();while(watch.ElapsedMilliseconds<150){Application.DoEvents();Thread.Sleep(5);}timer.Stop();
                Check(f.Writes.Count==1&&f.Actual==35,"WinForms timer dispatch applies queued volume without manual Tick");
            }
            using(Fixture f=new Fixture())
            {
                f.Midi(10);f.Midi(60);f.Midi(127);f.Tick();
                Check(f.Writes.Count==1&&f.Writes[0]==100&&f.Actual==100,"MIDI burst writes latest value once");
                f.Tick();Check(f.Writes.Count==1,"idle tick does not repeat completed volume write");
            }
            using(Fixture f=new Fixture())
            {
                f.Pending(50);f.Tick();f.Actual=20;f.Ready(f.Fader);f.Pending(50);f.Tick();
                Check(f.Writes.Count==2&&f.Actual==50,"same requested value is reapplied after external volume change");
            }
            using(Fixture f=new Fixture())
            {
                f.Failures=1;f.Pending(75);f.Tick();
                Check(f.Actual==50&&(int)BGet(f.Fader,"PendingPct")==75,"failed volume write retains latest pending request");
                f.Tick();Check(f.Writes.Count==1,"failed request backs off instead of retrying every timer tick");
                f.Ready(f.Fader);f.Tick();
                Check(f.Writes.Count==2&&f.Actual==75&&(int)BGet(f.Fader,"PendingPct")==-1,"next eligible tick retries transient missing session");
            }
            using(Fixture f=new Fixture())
            {
                f.Failures=1;f.ThrowFailure=true;f.Pending(65);f.Tick();f.Ready(f.Fader);f.Tick();
                Check(f.Writes.Count==2&&f.Actual==65,"backend exception does not lose queued fader request");
            }
            using(Fixture f=new Fixture())
            {
                BSet(f.Fader,"LastApplied",DateTime.UtcNow);f.Pending(55);f.Tick();
                Check(f.Writes.Count==0&&(int)BGet(f.Fader,"PendingPct")==55,"throttle defers request without discarding it");
                f.Ready(f.Fader);f.Tick();Check(f.Writes.Count==1&&f.Actual==55,"deferred request runs after throttle interval");
            }
            using(Fixture f=new Fixture())
            {
                f.Form.Hide();f.Pending(25);f.Tick();
                Check(f.Writes.Count==1&&f.Actual==25,"hidden form keeps applying mixer requests");
            }
            using(Fixture f=new Fixture())
            {
                ((ComboBox[])Get(f.Form,"knobMode"))[0].SelectedIndex=0;
                Call(f.Form,"ProcessKnob",f.Knob,1);Call(f.Form,"ProcessKnob",f.Knob,1);Call(f.Form,"ProcessKnob",f.Knob,65);
                Check(f.Writes.Count==0,"relative encoder batch waits for timer");
                f.Tick();Check(f.Reads==1&&f.Writes.Count==1&&f.Actual==52,"relative encoder direction batch reads and writes backend once");
                f.Tick();Check(f.Writes.Count==1,"completed encoder batch is not replayed");
            }
            using(Fixture f=new Fixture())
            {
                ((ComboBox[])Get(f.Form,"knobMode"))[0].SelectedIndex=1;
                Call(f.Form,"ProcessKnob",f.Knob,64);Call(f.Form,"ProcessKnob",f.Knob,66);Call(f.Form,"ProcessKnob",f.Knob,65);f.Tick();
                Check(f.Writes.Count==1&&f.Actual==52,"absolute encoder deltas preserve direction");
            }
            using(Fixture f=new Fixture())
            {
                f.Pending(10);Call(f.Form,"ChangeTarget",f.Fader,"other.exe");f.Tick();
                Check(f.Writes.Count==0,"changing app clears stale pending fader writes");
                Call(f.Form,"ProcessKnob",f.Knob,1);Call(f.Form,"ChangeTarget",f.Knob,"other.exe");f.Tick();
                Check(f.Writes.Count==0,"changing app clears stale pending encoder writes");
            }
            using(Fixture f=new Fixture())
            {
                f.Failures=1;Call(f.Form,"ProcessKnob",f.Knob,1);f.Tick();
                Check(f.Actual==50&&((int[])Get(f.Form,"knobPendingSteps"))[0]==1,"failed encoder write retains pending steps");
                f.Ready(f.Knob);f.Tick();
                Check(f.Writes.Count==2&&f.Actual==52&&((int[])Get(f.Form,"knobPendingSteps"))[0]==0,"encoder write retries after transient failure");
            }
            using(Fixture f=new Fixture())
            {
                f.ReadFailures=1;Call(f.Form,"ProcessKnob",f.Knob,1);f.Tick();
                Check(f.Writes.Count==0&&((int[])Get(f.Form,"knobPendingSteps"))[0]==1,"missing encoder session preserves pending steps");
                f.Ready(f.Knob);f.Tick();
                Check(f.Reads==2&&f.Writes.Count==1&&f.Actual==52,"encoder retries transient session lookup failure");
            }
            using(Fixture f=new Fixture())
            {
                f.Failures=10;f.Pending(15);f.Tick();
                BSet(f.Fader,"PendingExpiresAt",DateTime.UtcNow.AddSeconds(-1));f.Ready(f.Fader);f.Tick();
                Check(f.Writes.Count==1&&(int)BGet(f.Fader,"PendingPct")==-1,"expired failed request stops retrying");
                f.Failures=0;f.Pending(40);f.Ready(f.Fader);f.Tick();
                Check(f.Actual==40,"new input works after expired failed request");
            }
            using(Fixture f=new Fixture())
            {
                Call(f.Form,"ChangeTarget",f.Fader,"");f.Pending(80);f.Tick();
                Check(f.Writes.Count==0,"unassigned fader never calls audio writer");
                BSet(f.Fader,"PendingExpiresAt",DateTime.UtcNow.AddSeconds(-1));f.Ready(f.Fader);f.Tick();
                Check((int)BGet(f.Fader,"PendingPct")==-1,"unassigned request expires without busy retry loop");
            }
            Console.WriteLine("ALL "+passed+" VOLUME INTEGRATION CHECKS PASSED");return 0;
        }
        catch(Exception ex) { Console.Error.WriteLine(ex);return 1; }
    }
}
